package com.melmatech.app

import android.content.Context
import android.os.Bundle
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.print.PrintAttributes
import android.print.PrintManager
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.util.Base64

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.ContentScale

import coil.compose.rememberAsyncImagePainter
import org.json.JSONArray
import org.json.JSONObject

import java.util.Locale
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PageRange
import android.os.CancellationSignal
import java.io.FileInputStream
import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import java.util.concurrent.TimeUnit
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Dialog
import kotlin.math.max
import kotlin.math.roundToInt
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Email
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.input.VisualTransformation
import android.graphics.Canvas as AndroidCanvas
import android.graphics.RectF
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.selection.selectable


data class Produit(
    val id: Long,
    val nom: String,
    val achat: Double,
    val vente: Double,
    val quantite: Int,
    val supabaseId: String? = null,
    val codeBarres: String = ""
)

data class LigneVente(
    val produitId: Long,
    val nom: String,
    val quantite: Int,
    val prixUnitaire: Double,
    val prixAchat: Double
) {
    val total: Double get() = prixUnitaire * quantite
}

data class Vente(
    val id: Long,
    val client: String,
    val lignes: List<LigneVente>,
    val paye: Double,
    val date: Long
) {
    val total: Double get() = lignes.sumOf { it.total }
    val reste: Double get() = (total - paye).coerceAtLeast(0.0)
    val cout: Double get() = lignes.sumOf {
        it.prixAchat * it.quantite
    }
}

data class Depense(
    val id: Long,
    val description: String,
    val montant: Double,
    val date: Long
)

fun argent(montant: Double, devise: String = "USD"): String {
    val montantFormate = String.format(
        Locale.US,
        "%,.2f",
        montant
    )

    return if (devise == "CDF") {
        "$montantFormate FC"
    } else {
        "$$montantFormate"
    }
}
fun formaterDate(timestamp: Long): String {
    val format = SimpleDateFormat(
        "dd/MM/yyyy à HH:mm",
        Locale.FRANCE
    )

    return format.format(Date(timestamp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MelmaTechApp(context: Context) {

    val prefs = remember {
        context.getSharedPreferences("melmatech", Context.MODE_PRIVATE)
    }

    var utilisateurConnecte by remember {
        mutableStateOf(AuthService.estConnecte(context))
    }

    var roleUtilisateur by remember {
        mutableStateOf<String?>(null)
    }
    var nomProfilConnecte by remember { mutableStateOf("") }
    var photoProfilConnecte by remember { mutableStateOf("") }

    var page by remember { mutableStateOf("Accueil") }
    var devise by remember {
    mutableStateOf(prefs.getString("devise", "USD") ?: "USD")
    }
    
    // Informations de l'entreprise
    var nomEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_nom", "") ?: "")
    }
    
var lieuEntreprise by remember {
    mutableStateOf(prefs.getString("entreprise_lieu", "") ?: "")
}

var nomGerant by remember {
    mutableStateOf(prefs.getString("entreprise_gerant", "") ?: "")
}

var fonctionGerant by remember {
    mutableStateOf(
        prefs.getString("entreprise_fonction_gerant", "Gérant") ?: "Gérant"
    )
}


    var adresseEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_adresse", "") ?: "")
    }

    var emailEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_email", "") ?: "")
    }

    var telephoneEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_telephone", "") ?: "")
    }

    var rccmEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_rccm", "") ?: "")
    }

    var idNatEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_idnat", "") ?: "")
    }

    var impotEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_impot", "") ?: "")
    }

    var logoEntreprise by remember {
        mutableStateOf(prefs.getString("entreprise_logo", "") ?: "")
    }
    var tailleLogoEntreprise by remember {
    mutableStateOf(prefs.getFloat("entreprise_logo_taille", 1f))
    }

    var messageEntreprise by remember {
        mutableStateOf("")
    }

    val choisirLogo = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )

                logoEntreprise = uri.toString()

                prefs.edit()
                    .putString("entreprise_logo", logoEntreprise)
                    .apply()

                messageEntreprise = "Logo sélectionné avec succès."
            } catch (e: Exception) {
                messageEntreprise = "Impossible d'enregistrer ce logo."
            }
        }
    }


    var photoProfilUri by remember {
    mutableStateOf<Uri?>(null)
}

val choisirPhotoProfil = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
) { uri ->
    if (uri != null) {
        photoProfilUri = uri
    }
}
    var email by remember { mutableStateOf("") }
    var motDePasse by remember { mutableStateOf("") }
    var modeCreation by remember { mutableStateOf(false) }
    var chargement by remember { mutableStateOf(false) }
    var messageConnexion by remember { mutableStateOf("") }

    var messageProduit by remember { mutableStateOf("") }
    var messageVente by remember { mutableStateOf("") }
    var fichierFactureEnAttente by remember {
    mutableStateOf<File?>(null)
}
    var fichierRapportEnAttente by remember {
    mutableStateOf<File?>(null)
}

val enregistrerRapportLauncher =
    rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val fichier = fichierRapportEnAttente

        if (uri != null && fichier != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { sortie ->
                    fichier.inputStream().use { entree ->
                        entree.copyTo(sortie)
                    }
                }
            } catch (e: Exception) {
                messageVente = "Erreur d'enregistrement du rapport : ${e.message}"
            }
        }

        fichierRapportEnAttente = null
    }

val enregistrerFactureLauncher =
    rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val fichier = fichierFactureEnAttente

        if (uri != null && fichier != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { sortie ->
                    fichier.inputStream().use { entree ->
                        entree.copyTo(sortie)
                    }
                }
                messageVente = "Facture enregistrée avec succès."
            } catch (e: Exception) {
                messageVente = "Erreur d'enregistrement : ${e.message}"
            }
        }

        fichierFactureEnAttente = null
    }

    var messageDepense by remember { mutableStateOf("") }

    var chargementProduits by remember {
        mutableStateOf(false)
    }

    val estAdministrateur =
        roleUtilisateur == "administrateur" ||
        roleUtilisateur == "admin" ||
        roleUtilisateur == "manager"

    val produits = remember {
        mutableStateListOf<Produit>().apply {
            try {
                val json = JSONArray(
                    prefs.getString("produits", "[]")
                )

                for (i in 0 until json.length()) {
                    val p = json.getJSONObject(i)

                    add(
                        Produit(
                            id = p.getLong("id"),
                            nom = p.getString("nom"),
                            achat = p.getDouble("achat"),
                            vente = p.getDouble("vente"),
                            quantite = p.getInt("quantite"),
                            supabaseId = if (
                                p.isNull("supabaseId")
                            ) null else p.optString("supabaseId"),
                            codeBarres = p.optString("codeBarres", "")
                                .ifBlank { BarcodeUtils.genererCodeInterne() }
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    val ventes = remember {
        mutableStateListOf<Vente>().apply {
            try {
                val json = JSONArray(
                    prefs.getString("ventes_nouvelles", "[]")
                )

                for (i in 0 until json.length()) {
                    val v = json.getJSONObject(i)
                    val lignesJson = v.getJSONArray("lignes")
                    val lignes = mutableListOf<LigneVente>()

                    for (j in 0 until lignesJson.length()) {
                        val l = lignesJson.getJSONObject(j)

                        lignes.add(
                            LigneVente(
                                l.getLong("produitId"),
                                l.getString("nom"),
                                l.getInt("quantite"),
                                l.getDouble("prixUnitaire"),
                                l.getDouble("prixAchat")
                            )
                        )
                    }

                    add(
                        Vente(
                            v.getLong("id"),
                            v.getString("client"),
                            lignes,
                            v.getDouble("paye"),
                            v.getLong("date")
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    val depenses = remember {
        mutableStateListOf<Depense>().apply {
            try {
                val json = JSONArray(
                    prefs.getString("depenses", "[]")
                )

                for (i in 0 until json.length()) {
                    val d = json.getJSONObject(i)

                    add(
                        Depense(
                            d.getLong("id"),
                            d.getString("description"),
                            d.getDouble("montant"),
                            d.getLong("date")
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    fun sauvegarderProduits() {
        val json = JSONArray()

        produits.forEach { p ->
            json.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("nom", p.nom)
                    put("achat", p.achat)
                    put("vente", p.vente)
                    put("quantite", p.quantite)
                    put("supabaseId", p.supabaseId)
                    put("codeBarres", p.codeBarres)
                }
            )
        }

        prefs.edit()
            .putString("produits", json.toString())
            .apply()
    }

    // Sauvegarde aussi les codes générés à la première ouverture pour les anciens produits locaux.
    LaunchedEffect(Unit) {
        sauvegarderProduits()
    }

    fun sauvegarderVentes() {
        val json = JSONArray()

        ventes.forEach { v ->
            val lignes = JSONArray()

            v.lignes.forEach { l ->
                lignes.put(
                    JSONObject().apply {
                        put("produitId", l.produitId)
                        put("nom", l.nom)
                        put("quantite", l.quantite)
                        put("prixUnitaire", l.prixUnitaire)
                        put("prixAchat", l.prixAchat)
                    }
                )
            }

            json.put(
                JSONObject().apply {
                    put("id", v.id)
                    put("client", v.client)
                    put("lignes", lignes)
                    put("paye", v.paye)
                    put("date", v.date)
                }
            )
        }

        prefs.edit()
            .putString("ventes_nouvelles", json.toString())
            .apply()
    }

    fun sauvegarderDepenses() {
        val json = JSONArray()

        depenses.forEach { d ->
            json.put(
                JSONObject().apply {
                    put("id", d.id)
                    put("description", d.description)
                    put("montant", d.montant)
                    put("date", d.date)
                }
            )
        }

        prefs.edit()
            .putString("depenses", json.toString())
            .apply()
    }

    // Chargement du profil de l'utilisateur connecté pour l'en-tête du menu Plus.
    LaunchedEffect(utilisateurConnecte) {
        if (utilisateurConnecte) {
            AuthService.obtenirProfil(context) { succes, _, profil ->
                if (succes && profil != null) {
                    nomProfilConnecte = profil.nomComplet.orEmpty()
                    photoProfilConnecte = profil.photoUrl.orEmpty()
                }
            }
        } else {
            nomProfilConnecte = ""
            photoProfilConnecte = ""
        }
    }

    // Connexion et chargement des données du compte.
    LaunchedEffect(utilisateurConnecte) {
        if (utilisateurConnecte) {

            AuthService.obtenirRole(context) {
                    succes, message, role ->

                roleUtilisateur = if (succes) {
                    role?.lowercase(Locale.ROOT)
                } else {
                    null
                }

                if (!succes) {
                    messageConnexion = message
                }
            }

            val token = AuthService.obtenirAccessToken(context)

            if (!token.isNullOrBlank()) {
                chargementProduits = true

                AuthService.obtenirEntrepriseId(context) {
                        succes, message, entrepriseId ->

                    if (succes && entrepriseId != null) {
                        SupabaseService.chargerProduits(
                            token,
                            entrepriseId
                        ) { ok, resultat, liste ->

                            chargementProduits = false

                            if (ok && liste != null) {
                                produits.clear()

                                for (i in 0 until liste.length()) {
                                    val p = liste.getJSONObject(i)
                                    val uuid = p.getString("id")

                                    produits.add(
                                        Produit(
                                            id = uuid.hashCode().toLong(),
                                            nom = p.getString("nom"),
                                            achat = p.getDouble("prix_achat"),
                                            vente = p.getDouble("prix_vente"),
                                            quantite = p.getInt("quantite_stock"),
                                            supabaseId = uuid,
                                            codeBarres = p.optString("code_barres", "")
                                        )
                                    )
                                }

                                sauvegarderProduits()
                                messageProduit =
                                    "Produits chargés depuis Supabase."
                            } else {
                                messageProduit = resultat
                            }
                        }
                    } else {
                        chargementProduits = false
                        messageProduit = message
                    }
                }
            }
        } else {
            roleUtilisateur = null
        }
    }

    // Champs de gestion des produits.
    var nomProduit by remember { mutableStateOf("") }
    var achatProduit by remember { mutableStateOf("") }
    var venteProduit by remember { mutableStateOf("") }
    var stockProduit by remember { mutableStateOf("") }
    var editionId by remember { mutableStateOf<Long?>(null) }
    var rechercheProduit by remember { mutableStateOf("") }
    val produitsListState = rememberLazyListState()
    val produitsScope = rememberCoroutineScope()
    var produitPourCodeBarres by remember { mutableStateOf<Produit?>(null) }
    var afficherOptionsCodeBarres by remember { mutableStateOf(false) }
    var fichierCodeBarresEnAttente by remember { mutableStateOf<File?>(null) }
    val enregistrerCodeBarresLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val fichier = fichierCodeBarresEnAttente
        if (uri != null && fichier != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { sortie ->
                    fichier.inputStream().use { entree -> entree.copyTo(sortie) }
                }
                messageProduit = "PDF des codes-barres enregistré avec succès."
            } catch (e: Exception) {
                messageProduit = "Erreur d'enregistrement du PDF : ${e.message}"
            }
        }
        fichierCodeBarresEnAttente = null
    }
    var filtreProduit by remember { mutableStateOf("Tous") }
    var afficherScanner by remember { mutableStateOf(false) }
    var cibleScanner by remember { mutableStateOf("produit") }

    // Champs de vente.
    var client by remember { mutableStateOf("") }
    var recherche by remember { mutableStateOf("") }
    var produitChoisi by remember { mutableStateOf<Produit?>(null) }
    var quantiteSaisie by remember { mutableStateOf("1") }
    var panier by remember { mutableStateOf(listOf<LigneVente>()) }
    var derniereVenteValidee by remember {
    mutableStateOf<Vente?>(null)
    }
    var paiement by remember { mutableStateOf("") }
    var paiementId by remember { mutableStateOf<Long?>(null) }
    var paiementSupplementaire by remember { mutableStateOf("") }

    // Champs de dépenses.
    var descriptionDepense by remember { mutableStateOf("") }
    var montantDepense by remember { mutableStateOf("") }

    val chiffreAffaires = ventes.sumOf { it.total }
    val totalEncaisse = ventes.sumOf { it.paye }
    val totalDettes = ventes.sumOf { it.reste }
    val coutMarchandises = ventes.sumOf { it.cout }
    val totalDepenses = depenses.sumOf { it.montant }
    val benefice = chiffreAffaires - coutMarchandises - totalDepenses
    if (afficherScanner) {
        BarcodeScannerDialog(
            onDismiss = { afficherScanner = false },
            onBarcodeDetected = { code ->
                afficherScanner = false
                if (cibleScanner == "vente") {
                    recherche = code
                    val trouve = produits.firstOrNull {
                        it.codeBarres.equals(code, ignoreCase = true)
                    }
                    if (trouve != null) {
                        produitChoisi = trouve
                        quantiteSaisie = "1"
                    } else {
                        messageVente = "Aucun produit ne correspond à ce code-barres."
                    }
                } else {
                    rechercheProduit = code
                    val trouve = produits.firstOrNull {
                        it.codeBarres.equals(code, ignoreCase = true)
                    }
                    messageProduit = if (trouve == null)
                        "Aucun produit trouvé pour ce code-barres."
                    else "Produit trouvé : ${trouve.nom}"
                }
            }
        )
    }

    BackHandler(
    enabled = utilisateurConnecte && page != "Accueil"
) {
    page = when (page) {
        "Entreprise",
        "Paramètres",
        "Utilisateurs", "Personnel" -> "Plus"

        else -> "Accueil"
    }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF1565C0),
            secondary = androidx.compose.ui.graphics.Color(0xFF1976D2),
            background = androidx.compose.ui.graphics.Color(0xFFF5F7FA),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {

        if (!utilisateurConnecte) {

            EcranConnexion(
                email = email,
                onEmailChange = { email = it },
                motDePasse = motDePasse,
                onMotDePasseChange = { motDePasse = it },
                modeCreationCompte = modeCreation,
                chargement = chargement,
                message = messageConnexion,
                onChangerMode = {
                    modeCreation = !modeCreation
                    messageConnexion = ""
                },
                onValider = {
                    if (email.isBlank() || motDePasse.isBlank()) {
                        messageConnexion =
                            "Remplis l'e-mail et le mot de passe."
                    } else {
                        chargement = true

                        val callback: (Boolean, String) -> Unit =
                            { succes, message ->
                                chargement = false
                                messageConnexion = message

                                utilisateurConnecte =
                                    succes && AuthService.estConnecte(context)
                            }

                        if (modeCreation) {
                            AuthService.creerCompte(
                                context,
                                email.trim(),
                                motDePasse,
                                callback
                            )
                        } else {
                            AuthService.connexion(
                                context,
                                email.trim(),
                                motDePasse,
                                callback
                            )
                        }
                    }
                }
            )

        } else {

            Scaffold(
    topBar = {
        TopAppBar(
    title = {
    Text(
        text = "MelmaTech",
        color = Color(0xFF6C3CE9),
        fontWeight = FontWeight.Bold
    )
},
    colors = TopAppBarDefaults.topAppBarColors(
        containerColor = Color.White
    )
)
    },
                bottomBar = {
                    NavigationBar(
    containerColor = Color.White,
    contentColor = Color(0xFF6C3CE9)
) {
                        val onglets = if (estAdministrateur) {
                            listOf(
                                "Accueil",
                                "Produits",
                                "Ventes",
                                "Rapports",
                                "Plus"
                            )
                        } else {
                            listOf(
                                "Accueil",
                                "Ventes",
                                "Rapports",
                                "Plus"
                            )
                        }

                        onglets.forEach { onglet ->
    val icone = when (onglet) {
        "Accueil" -> Icons.Filled.Home
        "Produits" -> Icons.Filled.Inventory2
        "Ventes" -> Icons.Filled.ShoppingCart
        "Rapports" -> Icons.Filled.BarChart
        else -> Icons.Filled.MoreHoriz
    }

    NavigationBarItem(
        selected = page == onglet,
        colors = NavigationBarItemDefaults.colors(
    selectedIconColor = Color(0xFF6C3CE9),
    selectedTextColor = Color(0xFF6C3CE9),
    indicatorColor = Color(0xFFEDE5FF),
    unselectedIconColor = Color(0xFF8A8A8A),
    unselectedTextColor = Color(0xFF8A8A8A)
),
        onClick = { page = onglet },
        icon = {
            Icon(
                imageVector = icone,
                contentDescription = onglet
            )
        },
        label = {
            Text(
                text = onglet,
                maxLines = 1
            )
        }
    )
                        }
                    }
                }
            ) { padding ->

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(12.dp)
                ) {

                    // Empêche l'accès aux pages réservées.
                    if (
                        !estAdministrateur &&
                        (page == "Produits" || page == "Utilisateurs" || page == "Personnel")
                    ) {
                        page = "Accueil"
                    }

                    when (page) {

                        "Accueil" -> {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Color(0xFF6C3CE9),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(20.dp)
            ) {
                Text(
                    text = "Bienvenue sur MelmaTech",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(Modifier.height(6.dp))

                Text(
                    text = "Gestion de votre commerce en $devise",
                    color = Color.White
                )
            }
        }

        item {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(540.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                userScrollEnabled = false
            ) {
                item {
                    DashboardCard(
                        "Produits enregistrés",
                        produits.size.toString()
                    )
                }

                item {
                    DashboardCard(
                        "Chiffre d'affaires",
                        argent(chiffreAffaires, devise)
                    )
                }

                item {
                    DashboardCard(
                        "Argent encaissé",
                        argent(totalEncaisse, devise)
                    )
                }

                item {
                    DashboardCard(
                        "Dettes clients",
                        argent(totalDettes, devise)
                    )
                }

                item {
                    DashboardCard(
                        "Dépenses",
                        argent(totalDepenses, devise)
                    )
                }

                item {
                    DashboardCard(
                        "Bénéfice estimé",
                        argent(benefice, devise)
                    )
                }
            }
        }

        item {
            if (chargementProduits) {
                CircularProgressIndicator()
            }

            Text(messageProduit)
        }

        item {
            Button(
                onClick = {
                    SupabaseService.testerConnexion {
                        succes, message ->
                        messageConnexion = message
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Tester Supabase")
            }
        }
    }
                        }

                        
"Produits" -> {

    val totalProduits = produits.size

    val stockTotal = produits.sumOf { it.quantite }

    val produitsEnAlerte = produits.count {
        it.quantite in 1..5
    }

    val produitsEpuises = produits.count {
        it.quantite <= 0
    }

    val valeurStock = produits.sumOf {
        it.achat * it.quantite
    }

    val produitsFiltres = produits.filter { produit ->
        val rechercheOK =
            produit.nom.contains(rechercheProduit, ignoreCase = true) ||
            produit.codeBarres.contains(rechercheProduit.trim(), ignoreCase = true)

        val filtreOK = when (filtreProduit) {
            "Stock faible" -> produit.quantite in 1..5
            "Épuisés" -> produit.quantite <= 0
            else -> true
        }

        rechercheOK && filtreOK
    }

    if (!estAdministrateur) {

        Text("Accès réservé à l'administrateur.")

    } else {

        LazyColumn(
            state = produitsListState,
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF5426A8), RoundedCornerShape(24.dp))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "MELMATECH  /  INVENTAIRE",
                        color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Gestion des produits",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Suivez vos articles, vos quantités et la valeur de votre stock.",
                        color = Color.White.copy(alpha = 0.82f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Vue d'ensemble",
                        color = Color(0xFF17151C),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF17151D)),
                            border = BorderStroke(1.dp, Color(0xFF302A3A))
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("PRODUITS", color = Color(0xFFAAA4B5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text("$totalProduits", color = Color(0xFFB99AFB), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF17171D)),
                            border = BorderStroke(1.dp, Color(0xFF302A3A))
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("UNITÉS EN STOCK", color = Color(0xFFAAA4B5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text("$stockTotal", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF17171D)),
                            border = BorderStroke(1.dp, Color(0xFF302A3A))
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("STOCK FAIBLE", color = Color(0xFFAAA4B5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text("$produitsEnAlerte", color = Color(0xFFFFB454), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF17171D)),
                            border = BorderStroke(1.dp, Color(0xFF302A3A))
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("ÉPUISÉS", color = Color(0xFFAAA4B5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text("$produitsEpuises", color = Color(0xFFFF7777), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0E9FF)),
                        border = BorderStroke(1.dp, Color(0xFFE1D3FF))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("VALEUR DU STOCK", color = Color(0xFF675783), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(argent(valeurStock, devise), color = Color(0xFF5426A8), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            }
                            Icon(Icons.Filled.Inventory2, contentDescription = null, tint = Color(0xFF5426A8), modifier = Modifier.size(30.dp))
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = rechercheProduit,
                            onValueChange = { rechercheProduit = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Rechercher un produit ou un code…") },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF8B5CF6),
                                unfocusedBorderColor = Color(0xFFD7D1E0),
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedLeadingIconColor = Color(0xFF5426A8),
                                unfocusedLeadingIconColor = Color(0xFF77717F)
                            )
                        )
                        IconButton(
                            onClick = {
                                cibleScanner = "produit"
                                afficherScanner = true
                            },
                            modifier = Modifier
                                .size(54.dp)
                                .background(Color(0xFF5426A8), RoundedCornerShape(16.dp))
                        ) {
                            Icon(Icons.Filled.PhotoCamera, contentDescription = "Scanner un produit", tint = Color.White)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Tous", "Stock faible", "Épuisés").forEach { filtre ->
                            FilterChip(
                                selected = filtreProduit == filtre,
                                onClick = { filtreProduit = filtre },
                                label = { Text(filtre, fontWeight = FontWeight.SemiBold) },
                                shape = RoundedCornerShape(12.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFE9DEFF),
                                    selectedLabelColor = Color(0xFF5426A8)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = filtreProduit == filtre,
                                    borderColor = Color(0xFFD5CCDF),
                                    selectedBorderColor = Color(0xFFB99AFB)
                                )
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF101014)
                    ),
                    border = BorderStroke(1.dp, Color(0xFF29242F))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    if (editionId == null) "NOUVEAU PRODUIT" else "MODIFICATION",
                                    color = Color(0xFFB99AFB),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (editionId == null) "Ajouter un produit" else "Modifier un produit",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Icon(
                                imageVector = if (editionId == null) Icons.Filled.Add else Icons.Filled.Edit,
                                contentDescription = null,
                                tint = Color(0xFFB99AFB),
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        OutlinedTextField(
                            value = nomProduit,
                            onValueChange = { nomProduit = it },
                            label = { Text("Nom du produit") },
                            leadingIcon = { Icon(Icons.Filled.Inventory2, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF9B70F5),
                                unfocusedBorderColor = Color(0xFF45404D),
                                focusedLabelColor = Color(0xFFB99AFB),
                                unfocusedLabelColor = Color(0xFFAAA4B4),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = Color(0xFFB99AFB)
                            )
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = achatProduit,
                                onValueChange = { achatProduit = it },
                                label = { Text("Prix d'achat ($devise)") },
                                leadingIcon = { Icon(Icons.Filled.Payments, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF9B70F5), unfocusedBorderColor = Color(0xFF45404D),
                                    focusedLabelColor = Color(0xFFB99AFB), unfocusedLabelColor = Color(0xFFAAA4B4),
                                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Color(0xFFB99AFB)
                                )
                            )
                            OutlinedTextField(
                                value = venteProduit,
                                onValueChange = { venteProduit = it },
                                label = { Text("Prix de vente ($devise)") },
                                leadingIcon = { Icon(Icons.Filled.TrendingUp, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF9B70F5), unfocusedBorderColor = Color(0xFF45404D),
                                    focusedLabelColor = Color(0xFFB99AFB), unfocusedLabelColor = Color(0xFFAAA4B4),
                                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Color(0xFFB99AFB)
                                )
                            )
                        }

                        OutlinedTextField(
                            value = stockProduit,
                            onValueChange = { stockProduit = it },
                            label = { Text("Quantité en stock") },
                            leadingIcon = { Icon(Icons.Filled.Inventory2, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF9B70F5), unfocusedBorderColor = Color(0xFF45404D),
                                focusedLabelColor = Color(0xFFB99AFB), unfocusedLabelColor = Color(0xFFAAA4B4),
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Color(0xFFB99AFB)
                            )
                        )

                        Text(
                            if (editionId == null) "Un code-barres interne sera généré automatiquement." else "Le code-barres existant sera conservé.",
                            color = Color(0xFFAAA4B4),
                            style = MaterialTheme.typography.bodySmall
                        )

                        Button(
                            onClick = {
                                val a = achatProduit.replace(",", ".").toDoubleOrNull()
                                val v = venteProduit.replace(",", ".").toDoubleOrNull()
                                val q = stockProduit.toIntOrNull()
                                if (nomProduit.isBlank() || a == null || a < 0 || v == null || v < 0 || q == null || q < 0) {
                                    messageProduit = "Vérifie les informations du produit."
                                } else {
                                    val id = editionId
                                    if (id == null) {
                                        val nouvelId = System.currentTimeMillis()
                                        val codeInterne = BarcodeUtils.genererCodeInterne()
                                        produits.add(Produit(nouvelId, nomProduit.trim(), a, v, q, codeBarres = codeInterne))
                                        sauvegarderProduits()
                                        messageProduit = "Produit enregistré localement."
                                        val token = AuthService.obtenirAccessToken(context)
                                        if (!token.isNullOrBlank()) {
                                            AuthService.obtenirEntrepriseId(context) { ok, message, entrepriseId ->
                                                if (ok && entrepriseId != null) {
                                                    SupabaseService.ajouterProduit(token, entrepriseId, nomProduit.trim(), a, v, q, codeInterne) { enregistre, resultat, uuid ->
                                                        if (enregistre && uuid != null) {
                                                            val index = produits.indexOfFirst { it.id == nouvelId }
                                                            if (index >= 0) {
                                                                produits[index] = produits[index].copy(supabaseId = uuid)
                                                                sauvegarderProduits()
                                                            }
                                                        }
                                                        messageProduit = resultat
                                                    }
                                                } else messageProduit = message
                                            }
                                        }
                                    } else {
                                        val index = produits.indexOfFirst { it.id == id }
                                        if (index >= 0) produits[index] = produits[index].copy(nom = nomProduit.trim(), achat = a, vente = v, quantite = q)
                                        sauvegarderProduits()
                                        messageProduit = "Modification enregistrée localement. Synchronisation des modifications non activée."
                                    }
                                    nomProduit = ""
                                    achatProduit = ""
                                    venteProduit = ""
                                    stockProduit = ""
                                    editionId = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7041C8))
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (editionId == null) "Ajouter le produit" else "Enregistrer les modifications", fontWeight = FontWeight.Bold)
                        }
                        if (messageProduit.isNotBlank()) {
                            Text(messageProduit, color = Color(0xFFB99AFB), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item {
                Text(
                    "Catalogue des produits (${produitsFiltres.size})",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            items(
                produitsFiltres,
                key = { it.id }
            ) { p ->

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            p.nom,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Code-barres : ${p.codeBarres}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                        BarcodeCode128(p.codeBarres)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Achat : ${argent(p.achat, devise)}")
                            Text("Vente : ${argent(p.vente, devise)}")
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Quantité : ${p.quantite}")

                            Text(
                                when {
                                    p.quantite <= 0 -> "Épuisé"
                                    p.quantite <= 5 -> "Stock faible"
                                    else -> "Disponible"
                                },
                                color = when {
                                    p.quantite <= 0 -> Color.Red
                                    p.quantite <= 5 -> Color(0xFFD97706)
                                    else -> Color(0xFF16834A)
                                }
                            )
                        }

                        ActionsProduit(
    onModifier = {
        editionId = p.id
        nomProduit = p.nom
        achatProduit = p.achat.toString()
        venteProduit = p.vente.toString()
        stockProduit = p.quantite.toString()
        produitsScope.launch {
            produitsListState.animateScrollToItem(3)
        }
    },

    onCodeBarres = {
        produitPourCodeBarres = p
        afficherOptionsCodeBarres = true
    },

    onSupprimer = {
        produits.removeAll { it.id == p.id }
        sauvegarderProduits()
    }
)
                    }
                }
            }
        }
    }
}


                        "Depenses" -> {

    var messageDepense by remember {
        mutableStateOf("")
    }

    var depenseAModifier by remember {
        mutableStateOf<Depense?>(null)
    }

    var confirmerSuppression by remember {
        mutableStateOf<Depense?>(null)
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth()
                    .background(Color(0xFF5426A8), RoundedCornerShape(22.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("💳", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.width(10.dp))
                    Text("GESTION FINANCIÈRE", color = Color.White.copy(alpha = 0.78f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                }
                Text("Gestion des dépenses", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Suivez les sorties d'argent de votre commerce.", color = Color.White.copy(alpha = 0.82f))
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                border = BorderStroke(1.dp, Color(0xFF29252F))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        if (depenseAModifier != null)
                            "Modifier une dépense"
                        else
                            "Nouvelle dépense",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = descriptionDepense,
                        onValueChange = {
                            descriptionDepense = it
                        },
                        label = { Text("Description de la dépense") },
                        leadingIcon = { Text("📝") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                            focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                            cursorColor = Color(0xFFB99AFF)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = montantDepense,
                        onValueChange = {
                            montantDepense = it
                        },
                        label = { Text("Montant ($devise)") },
                        leadingIcon = { Text("💰") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                            focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                            cursorColor = Color(0xFFB99AFF)
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val montant = montantDepense
                                .replace(",", ".")
                                .toDoubleOrNull()

                            if (
                                descriptionDepense.isBlank() ||
                                montant == null ||
                                montant <= 0
                            ) {
                                messageDepense =
                                    "Vérifie la description et le montant."
                            } else {

                                if (depenseAModifier != null) {
                                    val ancienneDepense =
                                        depenseAModifier!!

                                    val index = depenses.indexOfFirst {
                                        it.id == ancienneDepense.id
                                    }

                                    if (index != -1) {
                                        depenses[index] =
                                            ancienneDepense.copy(
                                                description = descriptionDepense.trim(),
                                                montant = montant
                                            )
                                    }

                                    depenseAModifier = null

                                    messageDepense =
                                        "Dépense modifiée avec succès."

                                } else {
                                    val id = System.currentTimeMillis()

                                    depenses.add(
                                        Depense(
                                            id,
                                            descriptionDepense.trim(),
                                            montant,
                                            id
                                        )
                                    )

                                    messageDepense =
                                        "Dépense enregistrée avec succès."
                                }

                                sauvegarderDepenses()

                                descriptionDepense = ""
                                montantDepense = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7541D8), contentColor = Color.White)
                    ) {
                        Text(
                            if (depenseAModifier != null)
                                "Enregistrer les modifications"
                            else
                                "Enregistrer la dépense"
                        )
                    }

                    if (depenseAModifier != null) {
                        OutlinedButton(
                            onClick = {
                                depenseAModifier = null
                                descriptionDepense = ""
                                montantDepense = ""
                                messageDepense = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Annuler la modification")
                        }
                    }

                    if (messageDepense.isNotBlank()) {
                        Text(messageDepense)
                    }
                }
            }
        }

        item {
            Text("HISTORIQUE", color = Color(0xFF8B5CF6), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text("Dépenses récentes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF0E9FF)), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("TOTAL DES DÉPENSES", color = Color(0xFF675783), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text(argent(totalDepenses, devise), color = Color(0xFF5426A8), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    Text("📉", style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        if (depenses.isEmpty()) {
            item {
                Text("Aucune dépense enregistrée.")
            }
        }

        items(
            depenses.sortedByDescending { it.date },
            key = { it.id }
        ) { depense ->

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                border = BorderStroke(1.dp, Color(0xFF29252F))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        depense.description,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Text(argent(depense.montant, devise), color = Color(0xFFB99AFF), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                    Text("📅  ${formaterDate(depense.date)}", color = Color(0xFFAAA3B5))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(
                            onClick = {
                                depenseAModifier = depense
                                descriptionDepense = depense.description
                                montantDepense = depense.montant.toString()
                                messageDepense = ""
                            }
                        ) {
                            Text("Modifier")
                        }

                        TextButton(
                            onClick = {
                                confirmerSuppression = depense
                            }
                        ) {
                            Text(
                                "Supprimer",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmerSuppression != null) {
        AlertDialog(
            onDismissRequest = {
                confirmerSuppression = null
            },
            title = {
                Text("Supprimer cette dépense ?")
            },
            text = {
                Text(
                    "La dépense « ${confirmerSuppression!!.description} » sera supprimée définitivement."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val depense = confirmerSuppression!!

                        depenses.removeAll {
                            it.id == depense.id
                        }

                        sauvegarderDepenses()

                        if (depenseAModifier?.id == depense.id) {
                            depenseAModifier = null
                            descriptionDepense = ""
                            montantDepense = ""
                        }

                        confirmerSuppression = null
                        messageDepense = "Dépense supprimée."
                    }
                ) {
                    Text(
                        "Supprimer",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        confirmerSuppression = null
                    }
                ) {
                    Text("Annuler")
                }
            }
        )
    }
                        }
                        
                        "Ventes" -> {

    var ongletVente by remember {
        mutableStateOf("Nouvelle vente")
    }

    val chiffreAffairesVentes = ventes.sumOf { it.total }
    val nombreVentes = ventes.size
    val articlesVendus = ventes.sumOf { vente ->
        vente.lignes.sumOf { it.quantite }
    }

    val suggestions = produits.filter { produit ->
        produitChoisi == null &&
        recherche.isNotBlank() &&
        (
            produit.nom.contains(recherche.trim(), ignoreCase = true) ||
            produit.codeBarres.equals(recherche.trim(), ignoreCase = true)
        ) &&
        produit.quantite > 0
    }.take(8)

    val totalPanier = panier.sumOf { it.total }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {

        // EN-TÊTE
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Color(0xFF6C3CE9),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "MelmaTech",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )

                Text(
                    "Gestion des ventes",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    "Enregistrez vos ventes et suivez vos paiements.",
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        // STATISTIQUES
        item {
            Text(
                "Vue d'ensemble",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                Card(
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Text(
                            "Chiffre d'affaires",
                            style = MaterialTheme.typography.bodySmall
                        )

                        Text(
                            argent(chiffreAffairesVentes, devise),
                            color = Color(0xFF6C3CE9),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Text(
                            "Ventes",
                            style = MaterialTheme.typography.bodySmall
                        )

                        Text(
                            nombreVentes.toString(),
                            color = Color(0xFF6C3CE9),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Text(
                            "Articles vendus",
                            style = MaterialTheme.typography.bodySmall
                        )

                        Text(
                            articlesVendus.toString(),
                            color = Color(0xFF6C3CE9),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        // NAVIGATION ENTRE LES DEUX ONGLETS
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Color(0xFFF0EBFA),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {

                listOf(
                    "Nouvelle vente",
                    "Historique"
                ).forEach { onglet ->

                    val selectionne = ongletVente == onglet

                    Button(
                        onClick = {
                            ongletVente = onglet
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectionne)
                                Color(0xFF6C3CE9)
                            else
                                Color.Transparent,
                            contentColor = if (selectionne)
                                Color.White
                            else
                                Color(0xFF5426A8)
                        )
                    ) {
                        Text(
                            onglet,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // ==========================================
        // ONGLET NOUVELLE VENTE
        // ==========================================

        if (ongletVente == "Nouvelle vente") {

            item {
                Text(
                    "Informations du client",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = client,
                    onValueChange = {
                        client = it
                    },
                    label = {
                        Text("Nom du client")
                    },
                    placeholder = {
                        Text("Entrez le nom du client")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                Text(
                    "Ajouter des produits",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = recherche,
                        onValueChange = {
                            recherche = it
                            produitChoisi = null
                        },
                        label = { Text("Nom ou code-barres") },
                        placeholder = { Text("Nom ou référence...") },
                        leadingIcon = {
                            Icon(Icons.Filled.Search, contentDescription = "Rechercher")
                        },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    IconButton(onClick = {
                        cibleScanner = "vente"
                        afficherScanner = true
                    }) {
                        Icon(Icons.Filled.PhotoCamera, contentDescription = "Scanner pour la vente")
                    }
                }
            }

            // SUGGESTIONS DE PRODUITS
            if (suggestions.isNotEmpty()) {

                items(
                    suggestions,
                    key = { it.id }
                ) { produit ->

                    Card(
                        onClick = {
                            produitChoisi = produit
                            recherche = produit.nom
                            quantiteSaisie = "1"
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    produit.nom,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    "Prix : ${argent(produit.vente, devise)}",
                                    color = Color(0xFF6C3CE9)
                                )

                                Text(
                                    "Stock disponible : ${produit.quantite}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            Icon(
                                Icons.Filled.Add,
                                contentDescription = "Sélectionner",
                                tint = Color(0xFF6C3CE9)
                            )
                        }
                    }
                }
            }

            // PRODUIT SÉLECTIONNÉ
            item {

                produitChoisi?.let { produit ->

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFF1EBFC)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {

                            Text(
                                "Produit sélectionné",
                                color = Color(0xFF6C3CE9),
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                produit.nom,
                                style = MaterialTheme.typography.titleMedium
                            )

                            Text(
                                "Prix unitaire : ${argent(produit.vente, devise)}"
                            )

                            Text(
                                "Stock disponible : ${produit.quantite}"
                            )

                            OutlinedTextField(
                                value = quantiteSaisie,
                                onValueChange = {
                                    quantiteSaisie = it
                                },
                                label = {
                                    Text("Quantité")
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Button(
                                onClick = {

                                    val quantite =
                                        quantiteSaisie.toIntOrNull()

                                    val dejaAjoute = panier
                                        .filter {
                                            it.produitId == produit.id
                                        }
                                        .sumOf { it.quantite }

                                    if (
                                        quantite != null &&
                                        quantite > 0 &&
                                        quantite + dejaAjoute <= produit.quantite
                                    ) {

                                        val index = panier.indexOfFirst {
                                            it.produitId == produit.id
                                        }

                                        panier = if (index >= 0) {

                                            panier.mapIndexed { i, ligne ->

                                                if (i == index) {
                                                    ligne.copy(
                                                        quantite =
                                                            ligne.quantite + quantite
                                                    )
                                                } else {
                                                    ligne
                                                }
                                            }

                                        } else {

                                            panier + LigneVente(
                                                produit.id,
                                                produit.nom,
                                                quantite,
                                                produit.vente,
                                                produit.achat
                                            )
                                        }

                                        produitChoisi = null
                                        recherche = ""
                                        quantiteSaisie = "1"
                                        messageVente = ""

                                    } else {

                                        messageVente =
                                            "Quantité invalide ou stock insuffisant."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    Icons.Filled.Add,
                                    contentDescription = null
                                )

                                Spacer(Modifier.width(6.dp))

                                Text("Ajouter au panier")
                            }
                        }
                    }
                }
            }

            // PANIER
            item {
                Text(
                    "Mon panier (${panier.size} lignes)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            if (panier.isEmpty()) {

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🛒")

                            Text(
                                "Votre panier est vide.",
                                color = Color.Gray
                            )
                        }
                    }
                }

            } else {

                items(
                    panier,
                    key = { it.produitId }
                ) { ligne ->

                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    ligne.nom,
                                    fontWeight = FontWeight.Bold
                                )

                                Text("Quantité : ${ligne.quantite}")

                                Text(
                                    argent(ligne.total, devise),
                                    color = Color(0xFF6C3CE9),
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = {
                                    panier = panier.filter {
                                        it.produitId != ligne.produitId
                                    }
                                }
                            ) {
                                Icon(
                                    Icons.Filled.Delete,
                                    contentDescription = "Retirer",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }

            // PAIEMENT ET VALIDATION
            item {

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFF1EBFC)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {

                        Text(
                            "Récapitulatif",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            "Total à payer : ${argent(totalPanier, devise)}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color(0xFF6C3CE9),
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = paiement,
                            onValueChange = {
                                paiement = it
                            },
                            label = {
                                Text("Montant payé maintenant")
                            },
                            placeholder = {
                                Text("Exemple : 20")
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Decimal
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Text(
                            "Le montant restant sera automatiquement enregistré comme dette du client.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )

                        Button(
                            onClick = {

                                val montantPaye = paiement
                                    .replace(",", ".")
                                    .toDoubleOrNull()

                                if (
                                    panier.isEmpty() ||
                                    client.isBlank() ||
                                    montantPaye == null ||
                                    montantPaye < 0 ||
                                    montantPaye > totalPanier
                                ) {

                                    messageVente =
                                        "Vérifiez le client, le panier et le paiement."

                                } else {

                                    val stockOK = panier.all { ligne ->

                                        val produit = produits.find {
                                            it.id == ligne.produitId
                                        }

                                        produit != null &&
                                        ligne.quantite <= produit.quantite
                                    }

                                    if (!stockOK) {

                                        messageVente = "Stock insuffisant."

                                    } else {

                                        val id = System.currentTimeMillis()

                                        val nouvelleVente = Vente(
                                            id,
                                            client.trim(),
                                            panier.toList(),
                                            montantPaye,
                                            id
                                        )

                                        // Mise à jour du stock
                                        panier.forEach { ligne ->

                                            val index = produits.indexOfFirst {
                                                it.id == ligne.produitId
                                            }

                                            if (index >= 0) {

                                                val produit = produits[index]

                                                produits[index] = produit.copy(
                                                    quantite =
                                                        produit.quantite - ligne.quantite
                                                )
                                            }
                                        }

                                        // Enregistrement de la vente
                                        ventes.add(nouvelleVente)

                                        derniereVenteValidee = nouvelleVente

                                        sauvegarderProduits()
                                        sauvegarderVentes()

                                        messageVente =
                                            "Vente enregistrée. Facture n° $id"

                                        // Réinitialisation du formulaire
                                        panier = emptyList()
                                        client = ""
                                        recherche = ""
                                        produitChoisi = null
                                        quantiteSaisie = "1"
                                        paiement = ""

                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = panier.isNotEmpty()
                        ) {
                            Text("Valider la vente")
                        }

                        if (messageVente.isNotBlank()) {
                            Text(
                                messageVente,
                                color = if (
                                    messageVente.startsWith("Vente enregistrée")
                                ) Color(0xFF16803C)
                                else Color.Red
                            )
                        }
                    }
                }
            }

            // FACTURE APRÈS VALIDATION
            item {

                derniereVenteValidee?.let { vente ->

                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {

                            Text(
                                "Vente enregistrée",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16803C)
                            )

                            Text("Facture n° ${vente.id}")

                            Button(
                                onClick = {

                                    val fichier = genererFacturePdf(
                                        context,
                                        vente,
                                        devise,
                                        nomEntreprise,
                                        adresseEntreprise,
                                        telephoneEntreprise,
                                        emailEntreprise,
                                        rccmEntreprise,
                                        idNatEntreprise,
                                        impotEntreprise,
                                        logoEntreprise
                                    )

                                    fichierFactureEnAttente = fichier

                                    enregistrerFactureLauncher.launch(
                                        "Facture-${vente.id}.pdf"
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Enregistrer la facture PDF")
                            }

                            OutlinedButton(
                                onClick = {

                                    val fichier = genererFacturePdf(
                                        context,
                                        vente,
                                        devise,
                                        nomEntreprise,
                                        adresseEntreprise,
                                        telephoneEntreprise,
                                        emailEntreprise,
                                        rccmEntreprise,
                                        idNatEntreprise,
                                        impotEntreprise,
                                        logoEntreprise
                                    )

                                    imprimerFacture(context, fichier)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Imprimer la facture")
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // ONGLET HISTORIQUE
        // ==========================================

        else {

            item {
                Text(
                    "Historique des ventes",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    "Consultez les transactions et les paiements de vos clients.",
                    color = Color.Gray
                )
            }

            if (ventes.isEmpty()) {

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Aucune vente enregistrée.")
                        }
                    }
                }

            } else {

                items(
                    ventes.toList().reversed(),
                    key = { it.id }
                ) { vente ->

                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {

                            Text(
                                "Facture n° ${vente.id}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF6C3CE9)
                            )

                            Text("Client : ${vente.client}")

                            Text(
                                "Date : ${formaterDate(vente.date)}",
                                style = MaterialTheme.typography.bodySmall
                            )

                            HorizontalDivider()

                            vente.lignes.forEach { ligne ->

                                Text(
                                    "${ligne.nom} × ${ligne.quantite}"
                                )

                                Text(
                                    argent(ligne.total, devise),
                                    color = Color.Gray
                                )
                            }

                            HorizontalDivider()

                            Text(
                                "Total : ${argent(vente.total, devise)}",
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                "Payé : ${argent(vente.paye, devise)}",
                                color = Color(0xFF16803C)
                            )

                            Text(
                                "Reste : ${argent(vente.reste, devise)}",
                                color = if (vente.reste > 0)
                                    Color(0xFFD97706)
                                else
                                    Color(0xFF16803C),
                                fontWeight = FontWeight.Bold
                            )

                            // PAIEMENT SUPPLÉMENTAIRE
                            if (vente.reste > 0) {

                                if (paiementId == vente.id) {

                                    OutlinedTextField(
                                        value = paiementSupplementaire,
                                        onValueChange = {
                                            paiementSupplementaire = it
                                        },
                                        label = {
                                            Text("Paiement supplémentaire")
                                        },
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Decimal
                                        ),
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )

                                    Button(
                                        onClick = {

                                            val montant =
                                                paiementSupplementaire
                                                    .replace(",", ".")
                                                    .toDoubleOrNull()

                                            if (
                                                montant != null &&
                                                montant > 0 &&
                                                montant <= vente.reste
                                            ) {

                                                val index = ventes.indexOfFirst {
                                                    it.id == vente.id
                                                }

                                                if (index >= 0) {

                                                    ventes[index] = vente.copy(
                                                        paye = vente.paye + montant
                                                    )

                                                    sauvegarderVentes()
                                                }

                                                paiementId = null
                                                paiementSupplementaire = ""

                                                messageVente =
                                                    "Paiement enregistré."

                                            } else {

                                                messageVente =
                                                    "Montant invalide."
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Confirmer le paiement")
                                    }

                                    TextButton(
                                        onClick = {
                                            paiementId = null
                                            paiementSupplementaire = ""
                                        }
                                    ) {
                                        Text("Annuler")
                                    }

                                } else {

                                    OutlinedButton(
                                        onClick = {
                                            paiementId = vente.id
                                            paiementSupplementaire = ""
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Enregistrer un paiement")
                                    }
                                }
                            }

                            // FACTURE
                            OutlinedButton(
                                onClick = {

                                    val fichier = genererFacturePdf(
                                        context,
                                        vente,
                                        devise,
                                        nomEntreprise,
                                        adresseEntreprise,
                                        telephoneEntreprise,
                                        emailEntreprise,
                                        rccmEntreprise,
                                        idNatEntreprise,
                                        impotEntreprise,
                                        logoEntreprise
                                    )

                                    fichierFactureEnAttente = fichier

                                    enregistrerFactureLauncher.launch(
                                        "Facture-${vente.id}.pdf"
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Enregistrer la facture PDF")
                            }

                            OutlinedButton(
                                onClick = {

                                    val fichier = genererFacturePdf(
                                        context,
                                        vente,
                                        devise,
                                        nomEntreprise,
                                        adresseEntreprise,
                                        telephoneEntreprise,
                                        emailEntreprise,
                                        rccmEntreprise,
                                        idNatEntreprise,
                                        impotEntreprise,
                                        logoEntreprise
                                    )

                                    imprimerFacture(context, fichier)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Imprimer la facture")
                            }

                            if (messageVente.isNotBlank()) {
                                Text(
                                    messageVente,
                                    color = Color(0xFF16803C)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
                        }
                                                    
            
                        
"Rapports" -> {

    var periode by remember { mutableStateOf("Tout") }

    val maintenant = System.currentTimeMillis()

    fun debutPeriode(type: String): Long {
        val cal = java.util.Calendar.getInstance()

        when (type) {
            "Aujourd'hui" -> {
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
            }

            "Cette semaine" -> {
                cal.set(
                    java.util.Calendar.DAY_OF_WEEK,
                    java.util.Calendar.MONDAY
                )
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
            }

            "Ce mois" -> {
                cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
            }

            else -> return 0L
        }

        return cal.timeInMillis
    }

    val debut = debutPeriode(periode)

    val ventesFiltrees = ventes.filter {
        it.date >= debut && it.date <= maintenant
    }

    val depensesFiltrees = depenses.filter {
        it.date >= debut && it.date <= maintenant
    }

    val caPeriode = ventesFiltrees.sumOf { it.total }
    val encaissePeriode = ventesFiltrees.sumOf { it.paye }
    val dettesPeriode = ventesFiltrees.sumOf { it.reste }
    val coutPeriode = ventesFiltrees.sumOf { it.cout }
    val depensesPeriode = depensesFiltrees.sumOf { it.montant }

    val beneficeBrut = caPeriode - coutPeriode
    val beneficeNet = beneficeBrut - depensesPeriode

    val rapportProduits = ventesFiltrees
        .flatMap { it.lignes }
        .groupBy { it.produitId }
        .map { (_, lignes) ->
            val premiereLigne = lignes.first()
            val quantiteVendue = lignes.sumOf { it.quantite }
            val chiffreAffaires = lignes.sumOf { it.total }

            Triple(
                premiereLigne.nom,
                quantiteVendue,
                chiffreAffaires
            )
        }
        .sortedByDescending { it.second }

    val produitsFaibles = produits.filter {
        it.quantite in 1..5
    }

    val produitsEpuises = produits.filter {
        it.quantite <= 0
    }

    // Contenu du rapport des ventes.
    val contenuRapportVentes = buildList {
        add("Période : $periode")
        add("")
        add("RÉSUMÉ DES VENTES")
        add("Chiffre d'affaires : ${argent(caPeriode, devise)}")
        add("Montant encaissé : ${argent(encaissePeriode, devise)}")
        add("Dettes clients : ${argent(dettesPeriode, devise)}")
        add("Coût des marchandises : ${argent(coutPeriode, devise)}")
        add("")
        add("PRODUITS VENDUS")

        rapportProduits.forEach { produit ->
            add(
                "${produit.first} | Quantité : ${produit.second} | Total : ${
                    argent(produit.third, devise)
                }"
            )
        }

        add("")
        add("HISTORIQUE DES VENTES")

        ventesFiltrees.forEach { vente ->
            add("Client : ${vente.client}")
            add(
                "Date : ${
                    SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                    ).format(Date(vente.date))
                }"
            )
            add("Montant : ${argent(vente.total, devise)}")
            add("Payé : ${argent(vente.paye, devise)}")
            add("Reste : ${argent(vente.reste, devise)}")
            add("------------------------------")
        }
    }

    // Contenu du rapport des dépenses.
    val contenuRapportDepenses = buildList {
        add("Période : $periode")
        add("")
        add("RÉSUMÉ DES DÉPENSES")
        add("Total des dépenses : ${argent(depensesPeriode, devise)}")
        add("")
        add("HISTORIQUE DES DÉPENSES")

        depensesFiltrees.forEach { depense ->
            add("Description : ${depense.description}")
            add(
                "Date : ${
                    SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                    ).format(Date(depense.date))
                }"
            )
            add("Montant : ${argent(depense.montant, devise)}")
            add("------------------------------")
        }
    }

    // Contenu du rapport des bénéfices.
    val contenuRapportBenefices = buildList {
        add("Période : $periode")
        add("")
        add("RÉSUMÉ DES BÉNÉFICES")
        add("Chiffre d'affaires : ${argent(caPeriode, devise)}")
        add("Coût des marchandises : ${argent(coutPeriode, devise)}")
        add("Bénéfice brut : ${argent(beneficeBrut, devise)}")
        add("Dépenses : ${argent(depensesPeriode, devise)}")
        add("")
        add("BÉNÉFICE NET ESTIMÉ")
        add(argent(beneficeNet, devise))
    }

    // Contenu du rapport du stock.
    val contenuRapportStock = buildList {
        add(
            "Date du rapport : ${
                SimpleDateFormat(
                    "dd/MM/yyyy",
                    Locale.getDefault()
                ).format(Date())
            }"
        )
        add("")
        add("RÉSUMÉ DU STOCK")
        add("Nombre total de produits : ${produits.size}")
        add("Produits en stock faible : ${produitsFaibles.size}")
        add("Produits épuisés : ${produitsEpuises.size}")
        add("")
        add("ÉTAT DÉTAILLÉ DU STOCK")

        produits.forEach { produit ->
            add("Produit : ${produit.nom}")
            add("Quantité disponible : ${produit.quantite}")
            add("Prix de vente : ${argent(produit.vente, devise)}")

            when {
                produit.quantite <= 0 ->
                    add("État : ÉPUISÉ")

                produit.quantite <= 5 ->
                    add("État : STOCK FAIBLE")

                else ->
                    add("État : DISPONIBLE")
            }

            add("------------------------------")
        }
    }

    // Génération du fichier PDF avec les informations de l'entreprise.
    fun creerFichierRapport(
        titre: String,
        contenu: List<String>,
        periodePdf: String = periode
    ): File {
        return genererRapportDocumentPdf(
            context = context,
            titreRapport = titre,
            periode = periodePdf,
            contenu = contenu,
            nomEntreprise = nomEntreprise,
            adresseEntreprise = adresseEntreprise,
            telephoneEntreprise = telephoneEntreprise,
            emailEntreprise = emailEntreprise,
            rccmEntreprise = rccmEntreprise,
            idNatEntreprise = idNatEntreprise,
            impotEntreprise = impotEntreprise,
            logoEntreprise = logoEntreprise,
            lieuEntreprise = lieuEntreprise,
            nomGerant = nomGerant,
            fonctionGerant = fonctionGerant
        )
    }

    // Carte statistique réutilisable.
    @Composable
    fun CarteStatistique(
        titre: String,
        valeur: String,
        couleur: Color = Color(0xFF6C3CE9)
    ) {
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 2.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text(
                    titre,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF777777)
                )

                Text(
                    valeur,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = couleur
                )
            }
        }
    }

    // En-tête d'une section.
    @Composable
    fun TitreSection(
        numero: String,
        titre: String,
        description: String
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEDE5FF)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    numero,
                    color = Color(0xFF6C3CE9),
                    fontWeight = FontWeight.Bold
                )
            }

            Column {
                Text(
                    titre,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }
    }

    // Actions PDF.
    @Composable
    fun ActionsRapport(
        titre: String,
        contenu: List<String>,
        nomFichier: String,
        periodePdf: String = periode
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    fichierRapportEnAttente =
                        creerFichierRapport(
                            titre,
                            contenu,
                            periodePdf
                        )

                    enregistrerRapportLauncher.launch(nomFichier)
                },
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    "PDF",
                    maxLines = 1
                )
            }

            OutlinedButton(
                onClick = {
                    val fichier = creerFichierRapport(
                        titre,
                        contenu,
                        periodePdf
                    )

                    imprimerRapport(context, fichier)
                },
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    "Imprimer",
                    maxLines = 1
                )
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {

        // En-tête général.
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Color(0xFF6C3CE9),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "TABLEAU DE BORD",
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    "Rapports et analyses",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    "Suivez les performances et la santé financière de votre commerce.",
                    color = Color.White.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // Sélection de période.
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Période d'analyse",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        listOf("Aujourd'hui", "Cette semaine").forEach { choix ->
                            FilterChip(
                                selected = periode == choix,
                                onClick = { periode = choix },
                                label = {
                                    Text(
                                        choix,
                                        maxLines = 1
                                    )
                                }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        listOf("Ce mois", "Tout").forEach { choix ->
                            FilterChip(
                                selected = periode == choix,
                                onClick = { periode = choix },
                                label = {
                                    Text(
                                        choix,
                                        maxLines = 1
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // Résumé des ventes.
        item {
            TitreSection(
                "01",
                "Vue d'ensemble des ventes",
                "Les principaux indicateurs de votre activité."
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                CarteStatistique(
                    "Chiffre d'affaires",
                    argent(caPeriode, devise)
                )

                CarteStatistique(
                    "Ventes",
                    ventesFiltrees.size.toString()
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                CarteStatistique(
                    "Montant encaissé",
                    argent(encaissePeriode, devise),
                    Color(0xFF16834A)
                )

                CarteStatistique(
                    "Dettes clients",
                    argent(dettesPeriode, devise),
                    Color(0xFFD97706)
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Rapport des ventes",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )

                    Text(
                        "Exporter ou imprimer les ventes de la période sélectionnée.",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )

                    ActionsRapport(
                        "RAPPORT DES VENTES",
                        contenuRapportVentes,
                        "Rapport-Ventes.pdf"
                    )
                }
            }
        }

        // Bénéfices.
        item {
            TitreSection(
                "02",
                "Analyse des bénéfices",
                "Évaluation de la rentabilité du commerce."
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CarteStatistique(
                        "Coût des marchandises",
                        argent(coutPeriode, devise),
                        Color(0xFF64748B)
                    )

                    CarteStatistique(
                        "Bénéfice brut",
                        argent(beneficeBrut, devise),
                        Color(0xFF16834A)
                    )

                    CarteStatistique(
                        "Dépenses déduites",
                        argent(depensesPeriode, devise),
                        Color(0xFFD97706)
                    )

                    HorizontalDivider()

                    Text(
                        "Bénéfice net estimé",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Text(
                        argent(beneficeNet, devise),
                        color = if (beneficeNet >= 0)
                            Color(0xFF16834A)
                        else
                            Color(0xFFD32F2F),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    ActionsRapport(
                        "RAPPORT DES BÉNÉFICES",
                        contenuRapportBenefices,
                        "Rapport-Benefices.pdf"
                    )
                }
            }
        }

        // Produits vendus.
        item {
            TitreSection(
                "03",
                "Produits vendus",
                "Classement par quantité vendue."
            )
        }

        if (rapportProduits.isEmpty()) {
            item {
                Text(
                    "Aucun produit vendu pour cette période.",
                    color = Color.Gray
                )
            }
        }

        items(
            rapportProduits,
            key = { it.first }
        ) { produit ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            produit.first,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )

                        Text(
                            "Quantité vendue : ${produit.second}",
                            color = Color.Gray,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Text(
                        argent(produit.third, devise),
                        color = Color(0xFF6C3CE9),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Historique des ventes.
        item {
            TitreSection(
                "04",
                "Historique des ventes",
                "Détail des transactions réalisées."
            )
        }

        if (ventesFiltrees.isEmpty()) {
            item {
                Text(
                    "Aucune vente pour cette période.",
                    color = Color.Gray
                )
            }
        }

        items(
            ventesFiltrees.sortedByDescending { it.date },
            key = { it.id }
        ) { v ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "Facture n° ${v.id}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6C3CE9)
                    )

                    Text("Client : ${v.client}")

                    Text(
                        "Date : ${
                            SimpleDateFormat(
                                "dd/MM/yyyy HH:mm",
                                Locale.getDefault()
                            ).format(Date(v.date))
                        }",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )

                    HorizontalDivider()

                    Text("Total : ${argent(v.total, devise)}")
                    Text(
                        "Payé : ${argent(v.paye, devise)}",
                        color = Color(0xFF16834A)
                    )
                    Text(
                        "Reste : ${argent(v.reste, devise)}",
                        color = Color(0xFFD97706)
                    )

                    Text(
                        "Bénéfice sur cette vente : ${
                            argent(v.total - v.cout, devise)
                        }",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Dépenses.
        item {
            TitreSection(
                "05",
                "Dépenses",
                "Suivi des sorties d'argent."
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Total des dépenses",
                        color = Color.Gray
                    )

                    Text(
                        argent(depensesPeriode, devise),
                        color = Color(0xFFD97706),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.headlineSmall
                    )

                    Text(
                        "Nombre de dépenses : ${depensesFiltrees.size}"
                    )

                    ActionsRapport(
                        "RAPPORT DES DÉPENSES",
                        contenuRapportDepenses,
                        "Rapport-Depenses.pdf"
                    )
                }
            }
        }

        if (depensesFiltrees.isEmpty()) {
            item {
                Text(
                    "Aucune dépense pour cette période.",
                    color = Color.Gray
                )
            }
        }

        items(
            depensesFiltrees.sortedByDescending { it.date },
            key = { it.id }
        ) { d ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        d.description,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        argent(d.montant, devise),
                        color = Color(0xFFD97706),
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        SimpleDateFormat(
                            "dd/MM/yyyy HH:mm",
                            Locale.getDefault()
                        ).format(Date(d.date)),
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // État du stock.
        item {
            TitreSection(
                "06",
                "État du stock",
                "Produits disponibles et produits à surveiller."
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                CarteStatistique(
                    "Disponibles",
                    produits.count { it.quantite > 5 }.toString(),
                    Color(0xFF16834A)
                )

                CarteStatistique(
                    "Stock faible",
                    produitsFaibles.size.toString(),
                    Color(0xFFD97706)
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Produits épuisés",
                        color = Color.Gray
                    )

                    Text(
                        produitsEpuises.size.toString(),
                        color = Color(0xFFD32F2F),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.headlineMedium
                    )
                }
            }
        }

        if (produitsFaibles.isEmpty() && produitsEpuises.isEmpty()) {
            item {
                Text(
                    "Tous les produits ont un stock supérieur à 5 unités.",
                    color = Color(0xFF16834A)
                )
            }
        }

        items(
            produitsFaibles + produitsEpuises,
            key = { it.id }
        ) { p ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            p.nom,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            "Stock restant : ${p.quantite}",
                            color = Color.Gray
                        )
                    }

                    Text(
                        if (p.quantite <= 0) "ÉPUISÉ" else "FAIBLE",
                        color = if (p.quantite <= 0)
                            Color(0xFFD32F2F)
                        else
                            Color(0xFFD97706),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Export du rapport de stock.
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Rapport complet du stock",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "Situation actuelle de tous les produits enregistrés.",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )

                    ActionsRapport(
                        "RAPPORT DU STOCK",
                        contenuRapportStock,
                        "Rapport-Stock.pdf",
                        "Situation actuelle du stock"
                    )
                }
            }
        }
    }
}
 

                        "Plus" -> {

    var confirmerDeconnexion by remember {
        mutableStateOf(false)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF17131F)
                ),
                border = BorderStroke(1.dp, Color(0xFF342747))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF382451))
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (photoProfilConnecte.isNotBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(photoProfilConnecte),
                                contentDescription = "Photo de profil",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(
                                (nomProfilConnecte.ifBlank { email }
                                    .trim().firstOrNull()?.uppercaseChar()?.toString() ?: "M"),
                                color = Color.White,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            nomProfilConnecte.ifBlank {
                                email.ifBlank { "Utilisateur MelmaTech" }
                            },
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF55D69E))
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                when (roleUtilisateur?.lowercase(Locale.ROOT)) {
                                    "admin", "administrateur" -> "Administrateur"
                                    "manager" -> "Manager"
                                    "vendeur" -> "Vendeur"
                                    else -> if (estAdministrateur) "Administrateur" else "Vendeur"
                                },
                                color = Color(0xFFBDA6E8),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 2.dp)
            ) {
                Text(
                    "Plus",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB99AFF)
                )
                Text(
                    "Gérez votre compte et configurez MelmaTech.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFAAA3B5)
                )
            }
        }

        item {
            Text(
                "GESTION",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                onClick = { page = "Depenses" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                border = BorderStroke(1.dp, Color(0xFF29252F))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("💸", modifier = Modifier.background(Color(0xFF2A1B42), RoundedCornerShape(12.dp)).padding(10.dp), style = MaterialTheme.typography.headlineMedium)

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Dépenses et rapports",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            "Suivre les dépenses et les résultats.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAA3B5)
                        )
                    }

                    Text("›", color = Color(0xFFB99AFF), style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        item {
            Card(
                onClick = { page = "Ventes" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                border = BorderStroke(1.dp, Color(0xFF29252F))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🧾", modifier = Modifier.background(Color(0xFF2A1B42), RoundedCornerShape(12.dp)).padding(10.dp), style = MaterialTheme.typography.headlineMedium)

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Factures et ventes",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            "Consulter les ventes et les paiements.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAA3B5)
                        )
                    }

                    Text("›", color = Color(0xFFB99AFF), style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        if (estAdministrateur) {
            item {
                Text(
                    "ADMINISTRATION",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Card(
                    onClick = { page = "Utilisateurs" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("👥", modifier = Modifier.background(Color(0xFF2A1B42), RoundedCornerShape(12.dp)).padding(10.dp), style = MaterialTheme.typography.headlineMedium)

                        Spacer(Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Gestion des utilisateurs",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "Gérer les comptes des vendeurs.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Text("›", color = Color(0xFFB99AFF), style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        }

        if (estAdministrateur) {
            item {
                Card(
                    onClick = { page = "Personnel" },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                    border = BorderStroke(1.dp, Color(0xFF29252F))
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("👤", modifier = Modifier.background(Color(0xFF2A1B42), RoundedCornerShape(12.dp)).padding(10.dp), style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Gestion du personnel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color.White)
                            Text("Employés, matricules et dossiers du personnel.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAA3B5))
                        }
                        Text("›", color = Color(0xFFB99AFF), style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        }

        item {
            Text(
                "CONFIGURATION",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                onClick = { page = "Entreprise" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                border = BorderStroke(1.dp, Color(0xFF29252F))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🏢", modifier = Modifier.background(Color(0xFF2A1B42), RoundedCornerShape(12.dp)).padding(10.dp), style = MaterialTheme.typography.headlineMedium)

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Informations de l'entreprise",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            "Logo, adresse, contacts, RCCM et ID NAT.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAA3B5)
                        )
                    }

                    Text("›", color = Color(0xFFB99AFF), style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        item {
            Card(
                onClick = { page = "Paramètres" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101014)),
                border = BorderStroke(1.dp, Color(0xFF29252F))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚙️", modifier = Modifier.background(Color(0xFF2A1B42), RoundedCornerShape(12.dp)).padding(10.dp), style = MaterialTheme.typography.headlineMedium)

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Paramètres",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            "Devise et préférences de l'application.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAA3B5)
                        )
                    }

                    Text("›", color = Color(0xFFB99AFF), style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        item {
            Spacer(Modifier.height(4.dp))

            Card(
                onClick = { confirmerDeconnexion = true },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🚪", style = MaterialTheme.typography.headlineMedium)

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Déconnexion",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            "Fermer votre session en toute sécurité.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (confirmerDeconnexion) {
        Dialog(
            onDismissRequest = { confirmerDeconnexion = false }
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Color(0xFF17131F),
                border = BorderStroke(1.dp, Color(0xFF49345F)),
                shadowElevation = 18.dp
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF3A2030)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🚪", style = MaterialTheme.typography.headlineLarge)
                    }

                    Text(
                        "Se déconnecter ?",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "Voulez-vous vraiment fermer votre session MelmaTech ? Vous devrez vous reconnecter pour accéder à votre espace.",
                        color = Color(0xFFBDB5C8),
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { confirmerDeconnexion = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFD8C8F2)
                            ),
                            border = BorderStroke(1.dp, Color(0xFF665477))
                        ) {
                            Text("Annuler", maxLines = 1)
                        }

                        Button(
                            onClick = {
                                confirmerDeconnexion = false
                                AuthService.deconnecter(context)
                                utilisateurConnecte = false
                                page = "Accueil"
                                email = ""
                                motDePasse = ""
                                messageConnexion = ""
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFB3263E),
                                contentColor = Color.White
                            )
                        ) {
                            Text("Déconnexion", maxLines = 1)
                        }
                    }
                }
            }
        }
    }
                        }


                        "Entreprise" -> {

    if (!estAdministrateur) {
        Text("Accès réservé à l'administrateur.")
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(
                    Modifier.fillMaxWidth().background(Color(0xFF5426A8), RoundedCornerShape(22.dp)).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Text("🏢  PROFIL DE L'ENTREPRISE", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("Informations de l'entreprise", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Ces informations apparaîtront sur vos factures et documents officiels.", color = Color.White.copy(alpha = 0.82f))
                }
            }
            item {
                Text("IDENTITÉ ET COORDONNÉES", color = Color(0xFF8B5CF6), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }

            item {
                OutlinedTextField(
                    value = nomEntreprise,
                    onValueChange = { nomEntreprise = it },
                    label = { Text("Nom de l'entreprise") },
                    leadingIcon = { Text("🏢") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                OutlinedTextField(
                    value = adresseEntreprise,
                    onValueChange = { adresseEntreprise = it },
                    label = { Text("Adresse physique") },
                    leadingIcon = { Text("📍") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
    OutlinedTextField(
        value = lieuEntreprise,
        onValueChange = { lieuEntreprise = it },
        label = { Text("Lieu d'établissement des documents") },
                    leadingIcon = { Text("🗺️") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
        modifier = Modifier.fillMaxWidth()
    )
}

item {
    OutlinedTextField(
        value = nomGerant,
        onValueChange = { nomGerant = it },
        label = { Text("Nom du gérant") },
                    leadingIcon = { Text("👤") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
        modifier = Modifier.fillMaxWidth()
    )
}

item {
    OutlinedTextField(
        value = fonctionGerant,
        onValueChange = { fonctionGerant = it },
        label = { Text("Fonction du gérant") },
                    leadingIcon = { Text("💼") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
        modifier = Modifier.fillMaxWidth()
    )
}

            item {
                OutlinedTextField(
                    value = telephoneEntreprise,
                    onValueChange = { telephoneEntreprise = it },
                    label = { Text("Numéros de téléphone") },
                    leadingIcon = { Text("📞") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                OutlinedTextField(
                    value = emailEntreprise,
                    onValueChange = { emailEntreprise = it },
                    label = { Text("Adresse e-mail") },
                    leadingIcon = { Text("✉️") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item { Text("IDENTIFIANTS OFFICIELS", color = Color(0xFF8B5CF6), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold) }
            item {
                OutlinedTextField(
                    value = rccmEntreprise,
                    onValueChange = { rccmEntreprise = it },
                    label = { Text("Numéro RCCM") },
                    leadingIcon = { Text("📄") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                OutlinedTextField(
                    value = idNatEntreprise,
                    onValueChange = { idNatEntreprise = it },
                    label = { Text("Numéro ID NAT") },
                    leadingIcon = { Text("🪪") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                OutlinedTextField(
                    value = impotEntreprise,
                    onValueChange = { impotEntreprise = it },
                    label = { Text("Numéro d'impôt") },
                    leadingIcon = { Text("🧾") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF101014), unfocusedContainerColor = Color(0xFF101014),
                        focusedBorderColor = Color(0xFF9B72F2), unfocusedBorderColor = Color(0xFF514B5B),
                        focusedLabelColor = Color(0xFFB99AFF), unfocusedLabelColor = Color(0xFFB8B2C2),
                        cursorColor = Color(0xFFB99AFF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Text("IDENTITÉ VISUELLE", color = Color(0xFF8B5CF6), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text("Logo de l'entreprise", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                Button(
                    onClick = {
                        choisirLogo.launch(arrayOf("image/*"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Choisir le logo dans le téléphone")
                }

                if (logoEntreprise.isNotBlank()) {
    Image(
        painter = rememberAsyncImagePainter(model = logoEntreprise),
        contentDescription = "Logo de l'entreprise",
        modifier = Modifier.size(
            width = 160.dp * tailleLogoEntreprise,
            height = 120.dp * tailleLogoEntreprise
        ),
        contentScale = ContentScale.Fit
    )
                }
            }

            item {
                // Réglage de la taille du logo
Text("Taille du logo")

Text(
    when {
        tailleLogoEntreprise < 0.9f -> "Petit"
        tailleLogoEntreprise < 1.3f -> "Moyen"
        else -> "Grand"
    }
)

Slider(
    value = tailleLogoEntreprise,
    onValueChange = { tailleLogoEntreprise = it },
    valueRange = 0.7f..1.5f,
    steps = 1
)
            }
                item {
                    Button(
                    onClick = {
                        prefs.edit()
                            .putString("entreprise_nom", nomEntreprise)
                            .putString("entreprise_adresse", adresseEntreprise)
                            .putString("entreprise_telephone", telephoneEntreprise)
                            .putString("entreprise_email", emailEntreprise)
                            .putString("entreprise_rccm", rccmEntreprise)
                            .putString("entreprise_idnat", idNatEntreprise)
                            .putString("entreprise_impot", impotEntreprise)
                            .putString("entreprise_logo", logoEntreprise)
                            .putString("entreprise_lieu", lieuEntreprise)
                            .putString("entreprise_gerant", nomGerant)
                            .putString("entreprise_fonction_gerant", fonctionGerant)
                            .putFloat("entreprise_logo_taille", tailleLogoEntreprise)
.apply()
                        messageEntreprise = "Informations enregistrées avec succès."
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF7541D8),
                        contentColor = Color.White
                    )
                ) {
                    Text("✓  Enregistrer les informations")
                }

                Text(
                    messageEntreprise,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            item {
                OutlinedButton(
                    onClick = { page = "Plus" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Retour")
                }
            }
        }
    }
}

                        "Paramètres" -> {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Paramètres",
            style = MaterialTheme.typography.headlineSmall
        )

        Text("Configuration de MelmaTech")

        Text("Choisir la devise principale")

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = {
                    devise = "USD"
                    prefs.edit()
                        .putString("devise", "USD")
                        .apply()
                }
            ) {
                Text(if (devise == "USD") "✓ USD ($)" else "USD ($)")
            }

            OutlinedButton(
                onClick = {
                    devise = "CDF"
                    prefs.edit()
                        .putString("devise", "CDF")
                        .apply()
                }
            ) {
                Text(if (devise == "CDF") "✓ CDF (FC)" else "CDF (FC)")
            }
        }

        Text("Devise actuelle : $devise")

        Text("Version : 1.0")

        OutlinedButton(
            onClick = { page = "Plus" },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Retour")
        }
    }
}

                        
"Personnel" -> {
    if (!estAdministrateur) {
        Text("Accès réservé à l'administrateur et au manager.")
    } else {
        EcranPersonnel(onRetour = { page = "Plus" })
    }
}

"Utilisateurs" -> {

    if (!estAdministrateur) {
        Text("Accès réservé à l'administrateur.")
    } else {

        var vendeurs by remember {
            mutableStateOf(emptyList<AuthService.UtilisateurEntreprise>())
        }

        var profilAdmin by remember {
            mutableStateOf<ProfilUtilisateur?>(null)
        }

        var rechercheUtilisateur by remember {
            mutableStateOf("")
        }

        var filtreUtilisateur by remember {
            mutableStateOf("Tous")
        }

        var chargementUtilisateurs by remember {
            mutableStateOf(false)
        }

        var messageUtilisateurs by remember {
            mutableStateOf("")
        }

        var afficherFormulaire by remember {
            mutableStateOf(false)
        }

        var vendeurModifie by remember {
            mutableStateOf<AuthService.UtilisateurEntreprise?>(null)
        }

        var nomSaisi by remember {
            mutableStateOf("")
        }

        var emailSaisi by remember {
            mutableStateOf("")
        }

        var motDePasseSaisi by remember {
            mutableStateOf("")
        }

        var afficherMotDePasse by remember {
            mutableStateOf(false)
        }

        var vendeurMotDePasse by remember {
            mutableStateOf<AuthService.UtilisateurEntreprise?>(null)
        }

        var nouveauMotDePasse by remember {
            mutableStateOf("")
        }

        var vendeurAction by remember {
            mutableStateOf<AuthService.UtilisateurEntreprise?>(null)
        }

        var typeAction by remember {
            mutableStateOf("")
        }

        val violet = Color(0xFF6C3CE9)
        val fond = Color(0xFFF6F4FB)
        val vert = Color(0xFF159B68)
        val rouge = Color(0xFFD94B55)
        // Gestion des photos de profil
var utilisateurPhotoId by remember {
    mutableStateOf<String?>(null)
}
var photoARecadrer by remember {
    mutableStateOf<Bitmap?>(null)
}

var chargementPhoto by remember {
    mutableStateOf(false)
}


val choisirPhotoUtilisateur =
    rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->

        if (uri != null && utilisateurPhotoId != null) {

            chargementPhoto = true

            try {
                val typeMime =
                    context.contentResolver.getType(uri)
                        ?: "image/jpeg"

                if (typeMime !in listOf(
                        "image/jpeg",
                        "image/png",
                        "image/webp"
                    )
                ) {
                    chargementPhoto = false
                    messageUtilisateurs =
                        "Choisis une photo JPG, PNG ou WEBP."
                } else {

                    val image = context.contentResolver
                        .openInputStream(uri)
                        ?.use { it.readBytes() }

                    if (image == null || image.isEmpty()) {
                        chargementPhoto = false
                        messageUtilisateurs =
                            "Impossible de lire cette photo."
                    } else {

                        val bitmap = BitmapFactory.decodeByteArray(
                            image,
                            0,
                            image.size
                        )

                        chargementPhoto = false

                        if (bitmap == null) {
                            messageUtilisateurs =
                                "Impossible de décoder cette photo."
                        } else {
                            photoARecadrer = bitmap
                        }
                    }
                }

            } catch (e: Exception) {
                chargementPhoto = false
                messageUtilisateurs =
                    "Erreur lors de la lecture de la photo."
            }
        }
    }
    
val validerPhotoRecadree: (Bitmap) -> Unit = { bitmap ->

    val cibleId = utilisateurPhotoId

    if (!cibleId.isNullOrBlank()) {

        chargementPhoto = true

        val sortie = java.io.ByteArrayOutputStream()

        bitmap.compress(
            Bitmap.CompressFormat.JPEG,
            90,
            sortie
        )

        val imageFinale = sortie.toByteArray()

        AuthService.envoyerPhotoProfil(
            context = context,
            utilisateurCibleId = cibleId,
            image = imageFinale,
            typeMime = "image/jpeg"
        ) { succes, message, photoUrl ->

            chargementPhoto = false
            messageUtilisateurs = message

            if (succes && photoUrl != null) {

                if (cibleId == profilAdmin?.id) {

                    profilAdmin = profilAdmin?.copy(
                        photoUrl = photoUrl
                    )

                } else {

                    vendeurs = vendeurs.map { vendeur ->

                        if (vendeur.id == cibleId) {
                            vendeur.copy(photoUrl = photoUrl)
                        } else {
                            vendeur
                        }
                    }
                }

                photoARecadrer = null
                utilisateurPhotoId = null
            }
        }
    }
}



        val chargerVendeurs: () -> Unit = {
            chargementUtilisateurs = true

            AuthService.listerVendeurs(context) {
                    succes, message, liste ->

                chargementUtilisateurs = false

                if (succes) {
                    vendeurs = liste.filter {
                        it.role.equals("vendeur", ignoreCase = true)
                    }
                    messageUtilisateurs = ""
                } else {
                    messageUtilisateurs = message
                }
            }
        }

        LaunchedEffect(Unit) {
            AuthService.obtenirProfil(context) {
                    succes, _, profil ->
                if (succes) {
                    profilAdmin = profil
                }
            }

            chargerVendeurs()
        }

        val vendeursFiltres = vendeurs.filter { vendeur ->

            val correspondRecherche =
                vendeur.nomComplet.contains(
                    rechercheUtilisateur,
                    ignoreCase = true
                ) ||
                vendeur.email.contains(
                    rechercheUtilisateur,
                    ignoreCase = true
                )

            val correspondFiltre = when (filtreUtilisateur) {
                "Actifs" -> vendeur.actif
                "Inactifs" -> !vendeur.actif
                else -> true
            }

            correspondRecherche && correspondFiltre
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(fond)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            
            // EN-TÊTE DE GESTION DES UTILISATEURS

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        "Gestion des utilisateurs",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF252238)
                    )

                    Text(
                        "Gérez les accès et les membres de votre équipe.",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // CARTE ADMINISTRATEUR

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = violet
                    ),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 3.dp
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        if (!profilAdmin?.photoUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(
                                    profilAdmin?.photoUrl
                                ),
                                contentDescription = "Photo administrateur",
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Color.White.copy(alpha = 0.2f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "A",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.headlineMedium
                                )
                            }
                        }

                        Spacer(Modifier.width(14.dp))

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                profilAdmin?.nomComplet
                                    ?: "Administrateur MelmaTech",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )

                            Text(
                                "Administrateur",
                                color = Color.White.copy(alpha = 0.9f)
                            )

                            Text(
                                "Espace de gestion",
                                color = Color.White.copy(alpha = 0.75f),
                                style = MaterialTheme.typography.bodySmall
                            )

                            TextButton(
                                onClick = {
                                    utilisateurPhotoId = profilAdmin?.id
                                    if (utilisateurPhotoId != null) {
                                        choisirPhotoUtilisateur.launch("image/*")
                                    }
                                },
                                enabled = !chargementPhoto,
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(
                                    Icons.Filled.PhotoCamera,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )

                                Spacer(Modifier.width(6.dp))

                                Text(
                                    if (chargementPhoto)
                                        "Envoi en cours..."
                                    else
                                        "Changer la photo",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // BOUTON AJOUTER UN VENDEUR

            item {
                Button(
                    onClick = {
                        vendeurModifie = null
                        nomSaisi = ""
                        emailSaisi = ""
                        motDePasseSaisi = ""
                        messageUtilisateurs = ""
                        afficherFormulaire = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = violet
                    )
                ) {
                    Icon(
                        Icons.Filled.Add,
                        contentDescription = null
                    )

                    Spacer(Modifier.width(8.dp))

                    Text(
                        "Ajouter un vendeur",
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // STATISTIQUES

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                vendeurs.size.toString(),
                                color = violet,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                "Total",
                                color = Color.Gray,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                vendeurs.count { it.actif }.toString(),
                                color = vert,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                "Actifs",
                                color = Color.Gray,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                vendeurs.count { !it.actif }.toString(),
                                color = rouge,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                "Inactifs",
                                color = Color.Gray,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            // RECHERCHE

            item {
                OutlinedTextField(
                    value = rechercheUtilisateur,
                    onValueChange = {
                        rechercheUtilisateur = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    label = {
                        Text("Rechercher un vendeur")
                    },
                    placeholder = {
                        Text("Nom ou adresse e-mail")
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.Search,
                            contentDescription = "Rechercher",
                            tint = violet
                        )
                    }
                )
            }

            // FILTRES

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Tous", "Actifs", "Inactifs").forEach { filtre ->

                        FilterChip(
                            selected = filtreUtilisateur == filtre,
                            onClick = {
                                filtreUtilisateur = filtre
                            },
                            label = {
                                Text(
                                    filtre,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = violet.copy(
                                    alpha = 0.13f
                                ),
                                selectedLabelColor = violet
                            )
                        )
                    }
                }
            }

            item {
                Text(
                    "Équipe commerciale",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            if (chargementUtilisateurs) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = violet)
                    }
                }
            }

            if (messageUtilisateurs.isNotBlank()) {
                item {
                    Text(
                        messageUtilisateurs,
                        color = rouge
                    )
                }
            }

            if (!chargementUtilisateurs && vendeursFiltres.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "Aucun vendeur trouvé",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Ajoutez un vendeur ou modifiez votre recherche.",
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            items(
                vendeursFiltres,
                key = { it.id }
            ) { vendeur ->

                
Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(
        containerColor = Color.White
    ),
    elevation = CardDefaults.cardElevation(
        defaultElevation = 3.dp
    )
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        // INFORMATIONS DU VENDEUR

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            if (!vendeur.photoUrl.isNullOrBlank()) {
                Image(
                    painter = rememberAsyncImagePainter(
                        vendeur.photoUrl
                    ),
                    contentDescription = "Photo vendeur",
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(violet.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        vendeur.nomComplet.firstOrNull()
                            ?.uppercase() ?: "V",
                        color = violet,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    vendeur.nomComplet,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF252238)
                )

                Text(
                    vendeur.email,
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    "Vendeur",
                    color = violet,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (vendeur.actif)
                    Color(0xFFE4F5EF)
                else
                    Color(0xFFFCE8EA)
            ) {
                Text(
                    if (vendeur.actif) "Actif" else "Inactif",
                    modifier = Modifier.padding(
                        horizontal = 11.dp,
                        vertical = 7.dp
                    ),
                    color = if (vendeur.actif)
                        Color(0xFF15966B)
                    else
                        Color(0xFFD04452),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }

        // CHANGER LA PHOTO

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(
                onClick = {
                    utilisateurPhotoId = vendeur.id
                    choisirPhotoUtilisateur.launch("image/*")
                },
                enabled = !chargementPhoto
            ) {
                Icon(
                    imageVector = Icons.Filled.PhotoCamera,
                    contentDescription = "Changer la photo",
                    tint = violet,
                    modifier = Modifier.size(19.dp)
                )

                Spacer(Modifier.width(6.dp))

                Text(
                    "Changer la photo",
                    color = violet,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        HorizontalDivider(
            color = Color(0xFFF0EDF5)
        )

        // ACTIONS DU VENDEUR

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {

            IconButton(
                onClick = {
                    vendeurModifie = vendeur
                    nomSaisi = vendeur.nomComplet
                    emailSaisi = vendeur.email
                    messageUtilisateurs = ""
                    afficherFormulaire = true
                },
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        Color(0xFFEAF1FF),
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Icon(
                    Icons.Filled.Edit,
                    contentDescription = "Modifier",
                    tint = Color(0xFF2563EB)
                )
            }

            IconButton(
                onClick = {
                    vendeurMotDePasse = vendeur
                    nouveauMotDePasse = ""
                },
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        Color(0xFFF1EAFE),
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Icon(
                    Icons.Filled.LockReset,
                    contentDescription = "Mot de passe",
                    tint = Color(0xFF8B5CF6)
                )
            }

            IconButton(
                onClick = {
                    vendeurAction = vendeur
                    typeAction = if (vendeur.actif)
                        "desactiver"
                    else
                        "reactiver"
                },
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (vendeur.actif)
                            Color(0xFFFFF2E5)
                        else
                            Color(0xFFE4F5EF),
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Icon(
                    if (vendeur.actif)
                        Icons.Filled.Block
                    else
                        Icons.Filled.CheckCircle,
                    contentDescription = if (vendeur.actif)
                        "Désactiver"
                    else
                        "Réactiver",
                    tint = if (vendeur.actif)
                        Color(0xFFD97706)
                    else
                        Color(0xFF15966B)
                )
            }

            IconButton(
                onClick = {
                    vendeurAction = vendeur
                    typeAction = "supprimer"
                },
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        Color(0xFFFCE8EA),
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "Supprimer",
                    tint = Color(0xFFD04452)
                )
            }
        }
    }
}

            }

            item {
                Spacer(Modifier.height(20.dp))
            }
        }

                        if (afficherFormulaire) {
            AlertDialog(
                onDismissRequest = {
                    if (!chargementUtilisateurs) {
                        afficherFormulaire = false
                    }
                },
                containerColor = Color(0xFFF3F0FA),
                titleContentColor = Color(0xFF30145F),
                textContentColor = Color(0xFF655D70),
                title = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    Color(0xFF4B258D),
                                    RoundedCornerShape(14.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (vendeurModifie == null)
                                    Icons.Filled.Person
                                else
                                    Icons.Filled.Edit,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }

                        Text(
                            text = if (vendeurModifie == null)
                                "Ajouter un vendeur"
                            else
                                "Modifier le vendeur",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color(0xFF30145F)
                        )

                        Text(
                            text = if (vendeurModifie == null)
                                "Créez un accès pour un nouveau membre de votre équipe."
                            else
                                "Modifiez les informations de ce membre de votre équipe.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF655D70)
                        )
                    }
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = nomSaisi,
                            onValueChange = {
                                nomSaisi = it
                            },
                            label = {
                                Text("Nom complet")
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Filled.Person,
                                    contentDescription = null
                                )
                            },
                            singleLine = true,
                            enabled = !chargementUtilisateurs,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF6540A5),
                                unfocusedBorderColor = Color(0xFFD8D0E3),
                                focusedLeadingIconColor = Color(0xFF6540A5),
                                unfocusedLeadingIconColor = Color(0xFF81778F),
                                focusedLabelColor = Color(0xFF6540A5)
                            )
                        )

                        OutlinedTextField(
                            value = emailSaisi,
                            onValueChange = {
                                emailSaisi = it
                            },
                            label = {
                                Text("Adresse e-mail")
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Filled.Email,
                                    contentDescription = null
                                )
                            },
                            singleLine = true,
                            enabled = !chargementUtilisateurs,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF6540A5),
                                unfocusedBorderColor = Color(0xFFD8D0E3),
                                focusedLeadingIconColor = Color(0xFF6540A5),
                                unfocusedLeadingIconColor = Color(0xFF81778F),
                                focusedLabelColor = Color(0xFF6540A5)
                            )
                        )

                        if (vendeurModifie == null) {
                            OutlinedTextField(
                                value = motDePasseSaisi,
                                onValueChange = {
                                    motDePasseSaisi = it
                                },
                                label = {
                                    Text("Mot de passe temporaire")
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Filled.LockReset,
                                        contentDescription = null
                                    )
                                },
                                visualTransformation =
                                    PasswordVisualTransformation(),
                                singleLine = true,
                                enabled = !chargementUtilisateurs,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF6540A5),
                                    unfocusedBorderColor = Color(0xFFD8D0E3),
                                    focusedLeadingIconColor = Color(0xFF6540A5),
                                    unfocusedLeadingIconColor = Color(0xFF81778F),
                                    focusedLabelColor = Color(0xFF6540A5)
                                )
                            )

                            Text(
                                text = "Le vendeur pourra utiliser ces identifiants pour accéder à son compte.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF655D70)
                            )
                        }

                        if (messageUtilisateurs.isNotBlank()) {
                            Text(
                                text = messageUtilisateurs,
                                color = rouge,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        enabled = !chargementUtilisateurs,
                        onClick = {
                            val nom = nomSaisi.trim()
                            val email = emailSaisi.trim()

                            if (
                                nom.isBlank() ||
                                !email.contains("@")
                            ) {
                                messageUtilisateurs =
                                    "Vérifie le nom et l'adresse e-mail."
                            } else if (
                                vendeurModifie == null &&
                                motDePasseSaisi.length < 8
                            ) {
                                messageUtilisateurs =
                                    "Le mot de passe doit contenir au moins 8 caractères."
                            } else {
                                chargementUtilisateurs = true

                                if (vendeurModifie == null) {
                                    AuthService.creerVendeur(
                                        context,
                                        nom,
                                        email,
                                        motDePasseSaisi
                                    ) { succes, message ->

                                        chargementUtilisateurs = false
                                        messageUtilisateurs = message

                                        if (succes) {
                                            afficherFormulaire = false
                                            motDePasseSaisi = ""
                                            chargerVendeurs()
                                        }
                                    }
                                } else {
                                    AuthService.modifierVendeur(
                                        context,
                                        vendeurModifie!!.id,
                                        nom,
                                        email
                                    ) { succes, message ->

                                        chargementUtilisateurs = false
                                        messageUtilisateurs = message

                                        if (succes) {
                                            afficherFormulaire = false
                                            chargerVendeurs()
                                        }
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF4B258D),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (chargementUtilisateurs)
                                "Patiente..."
                            else if (vendeurModifie == null)
                                "Créer le vendeur"
                            else
                                "Enregistrer"
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        enabled = !chargementUtilisateurs,
                        onClick = {
                            afficherFormulaire = false
                        },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color(0xFF4B258D)
                        )
                    ) {
                        Text("Annuler")
                    }
                }
            )
                        }

        vendeurMotDePasse?.let { vendeur ->

            AlertDialog(
                onDismissRequest = {
                    vendeurMotDePasse = null
                },
                title = {
                    Text("Changer le mot de passe")
                },
                text = {
                    Column {
                        Text(vendeur.nomComplet)

                        OutlinedTextField(
                            value = nouveauMotDePasse,
                            onValueChange = {
                                nouveauMotDePasse = it
                            },
                            label = {
                                Text("Nouveau mot de passe")
                            },
                            visualTransformation =
                                PasswordVisualTransformation(),
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (nouveauMotDePasse.length < 8) {
                                messageUtilisateurs =
                                    "Minimum 8 caractères."
                            } else {
                                chargementUtilisateurs = true

                                AuthService.changerMotDePasseVendeur(
                                    context,
                                    vendeur.id,
                                    nouveauMotDePasse
                                ) { succes, message ->

                                    chargementUtilisateurs = false
                                    messageUtilisateurs = message

                                    if (succes) {
                                        vendeurMotDePasse = null
                                        nouveauMotDePasse = ""
                                    }
                                }
                            }
                        }
                    ) {
                        Text("Confirmer")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            vendeurMotDePasse = null
                        }
                    ) {
                        Text("Annuler")
                    }
                }
            )
        }

        vendeurAction?.let { vendeur ->

            val titreAction = when (typeAction) {
                "desactiver" -> "Désactiver ce vendeur ?"
                "reactiver" -> "Réactiver ce vendeur ?"
                else -> "Supprimer ce vendeur ?"
            }

            AlertDialog(
                onDismissRequest = {
                    vendeurAction = null
                },
                title = {
                    Text(titreAction)
                },
                text = {
                    Text(
                        when (typeAction) {
                            "desactiver" ->
                                "Le vendeur ne pourra plus accéder à son compte."
                            "reactiver" ->
                                "Le vendeur pourra de nouveau accéder à son compte."
                            else ->
                                "Le compte sera supprimé de la gestion. Vérifie avant de continuer."
                        }
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            chargementUtilisateurs = true

                            val action: (
                                (Boolean, String) -> Unit
                            ) -> Unit = { callback ->

                                when (typeAction) {
                                    "desactiver" ->
                                        AuthService.desactiverVendeur(
                                            context,
                                            vendeur.id,
                                            callback
                                        )

                                    "reactiver" ->
                                        AuthService.reactiverVendeur(
                                            context,
                                            vendeur.id,
                                            callback
                                        )

                                    else ->
                                        AuthService.supprimerVendeur(
                                            context,
                                            vendeur.id,
                                            callback
                                        )
                                }
                            }

                            action { succes, message ->

                                chargementUtilisateurs = false
                                messageUtilisateurs = message
                                vendeurAction = null

                                if (succes) {
                                    chargerVendeurs()
                                }
                            }
                        }
                    ) {
                        Text("Confirmer")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            vendeurAction = null
                        }
                    ) {
                        Text("Annuler")
                    }
                }
            )
        }
        photoARecadrer?.let { bitmap ->
    EditeurPhotoProfil(
        bitmap = bitmap,
        onAnnuler = {
            photoARecadrer = null
            utilisateurPhotoId = null
        },
        onValider = { photoRecadree ->
            validerPhotoRecadree(photoRecadree)
        }
    )
        }
    }
}
 

                        else -> {
                            Text("Page introuvable.")
                        }
                    }
                }
            }
        }
    }

    if (afficherOptionsCodeBarres && produitPourCodeBarres != null) {
        OptionsImpressionCodeBarres(
            produit = produitPourCodeBarres,
            onDismiss = { afficherOptionsCodeBarres = false },
            onAction = { format, enregistrer, tous ->
                val selection = if (tous) produits.toList() else listOfNotNull(produitPourCodeBarres)
                try {
                    val pdf = genererCodesBarresPdf(context, selection, format)
                    if (enregistrer) {
                        fichierCodeBarresEnAttente = pdf
                        enregistrerCodeBarresLauncher.launch("Codes-barres-MelmaTech.pdf")
                    } else {
                        imprimerFacture(context, pdf)
                        messageProduit = "Document envoyé au service d'impression Android."
                    }
                } catch (e: Exception) {
                    messageProduit = "Impossible de générer les codes-barres : ${e.message}"
                }
                afficherOptionsCodeBarres = false
            }
        )
    }
}

@Composable
fun DashboardCard(titre: String, montant: String) {

    val couleur = when (titre) {
        "Produits enregistrés" -> Color(0xFF6C3CE9)
        "Chiffre d'affaires" -> Color(0xFF2878D0)
        "Argent encaissé" -> Color(0xFF239B68)
        "Dettes clients" -> Color(0xFFE58B25)
        "Dépenses" -> Color(0xFFD95757)
        "Bénéfice estimé" -> Color(0xFF159EAD)
        else -> Color(0xFF6C3CE9)
    }

    val icone = when (titre) {
        "Produits enregistrés" -> Icons.Filled.Inventory2
        "Chiffre d'affaires" -> Icons.Filled.BarChart
        "Argent encaissé" -> Icons.Filled.Payments
        "Dettes clients" -> Icons.Filled.AccountBalanceWallet
        "Dépenses" -> Icons.Filled.MoneyOff
        "Bénéfice estimé" -> Icons.Filled.TrendingUp
        else -> Icons.Filled.BarChart
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = couleur
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Icon(
                imageVector = icone,
                contentDescription = titre,
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = titre,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = montant,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}


@Composable
fun EcranConnexion(
    email: String,
    onEmailChange: (String) -> Unit,
    motDePasse: String,
    onMotDePasseChange: (String) -> Unit,
    modeCreationCompte: Boolean,
    chargement: Boolean,
    message: String,
    onChangerMode: () -> Unit,
    onValider: () -> Unit
) {
    val fond = Color(0xFF0D0B14)
    val fondChamp = Color(0xFF191522)
    val violet = Color(0xFF8B5CF6)
    val violetClair = Color(0xFFC4A7FF)
    val blanc = Color.White
    val gris = Color(0xFFB8B2C5)

    var afficherMotDePasse by remember { mutableStateOf(false) }
    val focusMotDePasse = remember { FocusRequester() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = violet,
            secondary = violetClair,
            background = fond,
            surface = fondChamp,
            onPrimary = blanc,
            onBackground = blanc,
            onSurface = blanc
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF21143A), fond, fond)
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Spacer(Modifier.height(12.dp))

                Image(
                    painter = painterResource(id = R.drawable.melmatech_logo),
                    contentDescription = "Logo MelmaTech",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(155.dp),
                    contentScale = ContentScale.Fit
                )

                Spacer(Modifier.height(18.dp))

                Text(
                    text = if (modeCreationCompte) "Créer votre compte" else "Bienvenue",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = blanc
                )

                Spacer(Modifier.height(8.dp))

                Text(
                    text = if (modeCreationCompte)
                        "Rejoignez MelmaTech et gérez votre commerce"
                    else
                        "Connectez-vous à votre espace professionnel",
                    color = gris,
                    style = MaterialTheme.typography.bodyMedium
                )

                Spacer(Modifier.height(30.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = onEmailChange,
                    label = { Text("Adresse e-mail") },
                    placeholder = { Text("Entrez votre adresse e-mail", color = gris) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Email,
                            contentDescription = "Adresse e-mail",
                            tint = violetClair
                        )
                    },
                    singleLine = true,
                    enabled = !chargement,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusMotDePasse.requestFocus() }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = violet,
                        unfocusedBorderColor = Color(0xFF51465F),
                        focusedLabelColor = violetClair,
                        cursorColor = violetClair,
                        focusedTextColor = blanc,
                        unfocusedTextColor = blanc,
                        focusedContainerColor = fondChamp,
                        unfocusedContainerColor = fondChamp
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = motDePasse,
                    onValueChange = onMotDePasseChange,
                    label = { Text("Mot de passe") },
                    placeholder = { Text("Entrez votre mot de passe", color = gris) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = "Mot de passe",
                            tint = violetClair
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = { afficherMotDePasse = !afficherMotDePasse },
                            enabled = !chargement
                        ) {
                            Icon(
                                imageVector = if (afficherMotDePasse)
                                    Icons.Filled.VisibilityOff
                                else
                                    Icons.Filled.Visibility,
                                contentDescription = if (afficherMotDePasse)
                                    "Masquer le mot de passe"
                                else
                                    "Afficher le mot de passe",
                                tint = violetClair
                            )
                        }
                    },
                    singleLine = true,
                    enabled = !chargement,
                    visualTransformation = if (afficherMotDePasse)
                        VisualTransformation.None
                    else
                        PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onValider() }),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = violet,
                        unfocusedBorderColor = Color(0xFF51465F),
                        focusedLabelColor = violetClair,
                        cursorColor = violetClair,
                        focusedTextColor = blanc,
                        unfocusedTextColor = blanc,
                        focusedContainerColor = fondChamp,
                        unfocusedContainerColor = fondChamp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusMotDePasse)
                )

                Spacer(Modifier.height(26.dp))

                Button(
                    onClick = onValider,
                    enabled = !chargement,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = violet,
                        contentColor = blanc,
                        disabledContainerColor = Color(0xFF49356D),
                        disabledContentColor = gris
                    )
                ) {
                    if (chargement) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = blanc,
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("Patientez...")
                    } else {
                        Text(
                            text = if (modeCreationCompte)
                                "Créer mon compte"
                            else
                                "Se connecter",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                TextButton(
                    onClick = onChangerMode,
                    enabled = !chargement
                ) {
                    Text(
                        text = if (modeCreationCompte)
                            "J'ai déjà un compte ? Se connecter"
                        else
                            "Créer un nouveau compte",
                        color = violetClair,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (message.isNotBlank()) {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = message,
                        color = if (message.contains("erreur", ignoreCase = true))
                            Color(0xFFFF7777)
                        else
                            violetClair,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
@Composable
private fun OptionsImpressionCodeBarres(
    produit: Produit?,
    onDismiss: () -> Unit,
    onAction: (format: String, enregistrer: Boolean, tous: Boolean) -> Unit
) {
    if (produit == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Imprimer les codes-barres") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Produit : ${produit.nom}")
                Text("Choisis le format et l'action souhaitée.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = { onAction("ETIQUETTE", false, false) }, modifier = Modifier.fillMaxWidth()) { Text("Étiquette individuelle · Imprimer") }
                OutlinedButton(onClick = { onAction("ETIQUETTE", true, false) }, modifier = Modifier.fillMaxWidth()) { Text("Étiquette individuelle · PDF") }
                Button(onClick = { onAction("A4", false, true) }, modifier = Modifier.fillMaxWidth()) { Text("Planche A4 · Tous les produits") }
                OutlinedButton(onClick = { onAction("A4", true, true) }, modifier = Modifier.fillMaxWidth()) { Text("Planche A4 · Enregistrer PDF") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MelmaTechApp(this)
        }
    }
}
private fun genererFacturePdf(
    context: Context,
    vente: Vente,
    devise: String,
    nomEntreprise: String,
    adresseEntreprise: String,
    telephoneEntreprise: String,
    emailEntreprise: String,
    rccmEntreprise: String,
    idNatEntreprise: String,
    impotEntreprise: String,
    logoEntreprise: String
): File {
    val document = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val violet = android.graphics.Color.rgb(84, 38, 168)
    val violetPale = android.graphics.Color.rgb(243, 238, 252)
    val gris = android.graphics.Color.rgb(105, 105, 115)
    val noir = android.graphics.Color.rgb(30, 30, 30)

    fun paint(color: Int, size: Float, bold: Boolean = false): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create(
                Typeface.DEFAULT,
                if (bold) Typeface.BOLD else Typeface.NORMAL
            )
        }

    val titlePaint = paint(android.graphics.Color.WHITE, 24f, true)
    val headingPaint = paint(violet, 13f, true)
    val bodyPaint = paint(noir, 10f)
    val smallPaint = paint(gris, 8.5f)
    val boldPaint = paint(noir, 10f, true)
    val whitePaint = paint(android.graphics.Color.WHITE, 10f, true)
    val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(225, 222, 232)
        strokeWidth = 1f
    }
    val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = violetPale
        style = Paint.Style.FILL
    }
    val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = violet
        style = Paint.Style.FILL
    }

    val companyLines = listOf(
        adresseEntreprise, telephoneEntreprise, emailEntreprise,
        if (rccmEntreprise.isNotBlank()) "RCCM : $rccmEntreprise" else "",
        if (idNatEntreprise.isNotBlank()) "ID NAT : $idNatEntreprise" else "",
        if (impotEntreprise.isNotBlank()) "N° Impôt : $impotEntreprise" else ""
    ).filter { it.isNotBlank() }

    var logoBitmap: Bitmap? = null
    if (logoEntreprise.isNotBlank()) {
        try {
            context.contentResolver.openInputStream(Uri.parse(logoEntreprise))?.use {
                logoBitmap = BitmapFactory.decodeStream(it)
            }
        } catch (_: Exception) {}
    }

    val rowsPerPage = 12
    val pages = vente.lignes.chunked(rowsPerPage).ifEmpty { listOf(emptyList()) }
    val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(vente.date))
    val status = when {
        vente.reste <= 0.0 -> "PAYÉE"
        vente.paye > 0.0 -> "PARTIELLEMENT PAYÉE"
        else -> "EN ATTENTE"
    }
    val statusColor = if (vente.reste <= 0.0) android.graphics.Color.rgb(28, 145, 91)
        else android.graphics.Color.rgb(205, 125, 30)

    try {
        pages.forEachIndexed { pageIndex, lignes ->
            val page = document.startPage(
                PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            )
            val canvas = page.canvas

            // En-tête violet et identité de l'entreprise.
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 150f, headerPaint)
            canvas.drawText(nomEntreprise.ifBlank { "MelmaTech • Votre entreprise" }, 38f, 43f, titlePaint)
            var companyY = 66f
            companyLines.take(4).forEach {
                canvas.drawText(it.take(70), 38f, companyY, paint(android.graphics.Color.WHITE, 8.5f))
                companyY += 13f
            }
            logoBitmap?.let { bitmap ->
                val ratio = minOf(76f / bitmap.width, 76f / bitmap.height)
                val w = (bitmap.width * ratio).toInt().coerceAtLeast(1)
                val h = (bitmap.height * ratio).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
                canvas.drawBitmap(scaled, 480f, 28f, null)
                if (scaled !== bitmap) scaled.recycle()
            }

            // Titre, numéro et statut.
            canvas.drawText("FACTURE", 38f, 190f, paint(noir, 25f, true))
            canvas.drawText("N° ${vente.id}", 38f, 211f, smallPaint)
            val statusBox = android.graphics.RectF(390f, 166f, 557f, 198f)
            val statusBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.argb(24, statusColor shr 16 and 255, statusColor shr 8 and 255, statusColor and 255)
            }
            canvas.drawRoundRect(statusBox, 14f, 14f, statusBg)
            canvas.drawText(status, 402f, 186f, paint(statusColor, 8.5f, true))

            // Bloc client / date.
            canvas.drawRoundRect(android.graphics.RectF(38f, 230f, 557f, 306f), 12f, 12f, fillPaint)
            canvas.drawText("FACTURER À", 52f, 253f, headingPaint)
            canvas.drawText(vente.client.ifBlank { "Client comptant" }.take(42), 52f, 274f, boldPaint)
            canvas.drawText("Date d'émission", 365f, 253f, smallPaint)
            canvas.drawText(date, 365f, 274f, boldPaint)

            // Tableau des articles.
            var y = 342f
            canvas.drawRoundRect(android.graphics.RectF(38f, y - 22f, 557f, y + 8f), 7f, 7f, headerPaint)
            canvas.drawText("DÉSIGNATION", 50f, y - 2f, whitePaint)
            canvas.drawText("QTÉ", 330f, y - 2f, whitePaint)
            canvas.drawText("PRIX UNIT.", 390f, y - 2f, whitePaint)
            canvas.drawText("TOTAL", 490f, y - 2f, whitePaint)
            y += 28f

            lignes.forEachIndexed { rowIndex, ligne ->
                if (rowIndex % 2 == 0) {
                    val rowBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.rgb(249, 248, 252)
                    }
                    canvas.drawRect(38f, y - 16f, 557f, y + 9f, rowBg)
                }
                canvas.drawText(ligne.nom.take(34), 50f, y, bodyPaint)
                canvas.drawText(ligne.quantite.toString(), 330f, y, bodyPaint)
                canvas.drawText(String.format(Locale.US, "%.2f", ligne.prixUnitaire), 390f, y, bodyPaint)
                canvas.drawText(String.format(Locale.US, "%.2f", ligne.total), 490f, y, bodyPaint)
                y += 25f
            }

            if (pageIndex == pages.lastIndex) {
                y = maxOf(y + 25f, 690f)
                canvas.drawLine(320f, y - 10f, 557f, y - 10f, linePaint)
                canvas.drawText("TOTAL", 350f, y + 12f, boldPaint)
                canvas.drawText(argent(vente.total, devise), 465f, y + 12f, paint(violet, 12f, true))
                canvas.drawText("Montant payé", 350f, y + 38f, bodyPaint)
                canvas.drawText(argent(vente.paye, devise), 465f, y + 38f, bodyPaint)
                canvas.drawText("Solde restant", 350f, y + 64f, boldPaint)
                canvas.drawText(argent(vente.reste, devise), 465f, y + 64f, paint(statusColor, 11f, true))

                canvas.drawRoundRect(android.graphics.RectF(38f, 755f, 557f, 790f), 9f, 9f, fillPaint)
                val thanks = paint(violet, 10f, true).apply { textAlign = Paint.Align.CENTER }
                canvas.drawText("Merci pour votre confiance !", 297.5f, 777f, thanks)
                canvas.drawText("Document généré par MelmaTech", 297.5f, 822f, smallPaint.apply { textAlign = Paint.Align.CENTER })
            } else {
                canvas.drawText("Suite de la facture…", 38f, 805f, smallPaint)
                canvas.drawText("Page ${pageIndex + 1}/${pages.size}", 500f, 805f, smallPaint)
            }
            document.finishPage(page)
        }

        val folder = File(context.getExternalFilesDir(null), "Factures")
        if (!folder.exists()) folder.mkdirs()
        val file = File(folder, "Facture-${vente.id}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        return file
    } finally {
        logoBitmap?.recycle()
        document.close()
    }
}

private fun imprimerFacture(
    context: Context,
    fichier: File
) {
    val printManager = context.getSystemService(
        Context.PRINT_SERVICE
    ) as PrintManager

    val adapter = object : PrintDocumentAdapter() {

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) return

            val nombrePages = try {
                ParcelFileDescriptor.open(
                    fichier,
                    ParcelFileDescriptor.MODE_READ_ONLY
                ).use { descripteur ->
                    PdfRenderer(descripteur).use { renderer -> renderer.pageCount }
                }
            } catch (_: Exception) {
                1
            }
            val info = PrintDocumentInfo.Builder(fichier.name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(nombrePages)
                .build()

            callback.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<PageRange>,
            destination: ParcelFileDescriptor,
            cancellationSignal: CancellationSignal,
            callback: WriteResultCallback
        ) {
            try {
                FileInputStream(fichier).use { input ->
                    ParcelFileDescriptor.AutoCloseOutputStream(
                        destination
                    ).use { output ->
                        input.copyTo(output)
                    }
                }

                callback.onWriteFinished(
                    arrayOf(PageRange.ALL_PAGES)
                )
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            }
        }
    }

    printManager.print(
        "Facture-${fichier.name}",
        adapter,
        PrintAttributes.Builder().build()
    )
}
private fun imprimerRapport(context: Context, fichier: File) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager

    val adapter = object : android.print.PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: android.print.PrintAttributes?,
            newAttributes: android.print.PrintAttributes,
            cancellationSignal: android.os.CancellationSignal,
            callback: LayoutResultCallback,
            extras: android.os.Bundle?
        ) {
            if (cancellationSignal.isCanceled) return

            callback.onLayoutFinished(
                android.print.PrintDocumentInfo.Builder(fichier.name)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build(),
                true
            )
        }

        override fun onWrite(
            pages: Array<out android.print.PageRange>,
            destination: android.os.ParcelFileDescriptor,
            cancellationSignal: android.os.CancellationSignal,
            callback: WriteResultCallback
        ) {
            try {
                java.io.FileInputStream(fichier).use { input ->
                    java.io.FileOutputStream(destination.fileDescriptor).use { output ->
                        input.copyTo(output)
                    }
                }

                callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            }
        }
    }

    printManager.print(
        "Rapport-${fichier.name}",
        adapter,
        android.print.PrintAttributes.Builder().build()
    )
}

private fun genererRapportDocumentPdf(
    context: Context,
    titreRapport: String,
    periode: String,
    contenu: List<String>,
    nomEntreprise: String,
    adresseEntreprise: String,
    telephoneEntreprise: String,
    emailEntreprise: String,
    rccmEntreprise: String,
    idNatEntreprise: String,
    impotEntreprise: String,
    logoEntreprise: String,
    lieuEntreprise: String,
    nomGerant: String,
    fonctionGerant: String
): File {
    val document = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val violet = android.graphics.Color.rgb(84, 38, 168)
    val violetPale = android.graphics.Color.rgb(243, 238, 252)
    val ink = android.graphics.Color.rgb(35, 35, 42)
    val muted = android.graphics.Color.rgb(110, 110, 120)

    fun makePaint(color: Int, size: Float, bold: Boolean = false): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create(
                Typeface.DEFAULT,
                if (bold) Typeface.BOLD else Typeface.NORMAL
            )
        }

    val titlePaint = makePaint(ink, 20f, true)
    val bodyPaint = makePaint(ink, 9.5f)
    val smallPaint = makePaint(muted, 8f)
    val boldPaint = makePaint(ink, 9.5f, true)
    val purplePaint = makePaint(violet, 10f, true)
    val whitePaint = makePaint(android.graphics.Color.WHITE, 10f, true)
    val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = violet }
    val palePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = violetPale }
    val rulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(226, 222, 234)
        strokeWidth = 1f
    }

    var logo: Bitmap? = null
    if (logoEntreprise.isNotBlank()) {
        try {
            context.contentResolver.openInputStream(Uri.parse(logoEntreprise))?.use {
                logo = BitmapFactory.decodeStream(it)
            }
        } catch (_: Exception) {}
    }

    val linesPerPage = 22
    val groups = contenu.chunked(linesPerPage).ifEmpty { listOf(emptyList()) }
    val companyDetails = listOf(
        adresseEntreprise, telephoneEntreprise, emailEntreprise,
        if (rccmEntreprise.isNotBlank()) "RCCM : $rccmEntreprise" else "",
        if (idNatEntreprise.isNotBlank()) "ID NAT : $idNatEntreprise" else "",
        if (impotEntreprise.isNotBlank()) "N° Impôt : $impotEntreprise" else ""
    ).filter { it.isNotBlank() }

    try {
        groups.forEachIndexed { pageIndex, lines ->
            val page = document.startPage(
                PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            )
            val canvas = page.canvas

            // Bandeau de marque répété sur chaque page.
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 126f, headerPaint)
            canvas.drawText(nomEntreprise.ifBlank { "MelmaTech • Votre entreprise" }, 38f, 39f, whitePaint.apply { textSize = 17f })
            var detailY = 61f
            companyDetails.take(4).forEach {
                canvas.drawText(it.take(75), 38f, detailY, makePaint(android.graphics.Color.WHITE, 8f))
                detailY += 13f
            }
            logo?.let { bitmap ->
                val ratio = minOf(70f / bitmap.width, 70f / bitmap.height)
                val w = (bitmap.width * ratio).toInt().coerceAtLeast(1)
                val h = (bitmap.height * ratio).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
                canvas.drawBitmap(scaled, 490f, 25f, null)
                if (scaled !== bitmap) scaled.recycle()
            }

            canvas.drawText(titreRapport.take(55), 38f, 169f, titlePaint)
            canvas.drawText("Période : $periode", 38f, 190f, purplePaint)
            canvas.drawText("Émis le : " + SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()), 390f, 190f, smallPaint)
            canvas.drawLine(38f, 207f, 557f, 207f, rulePaint)

            // Tableau de lignes, avec alternance de fond.
            var y = 235f
            canvas.drawRoundRect(android.graphics.RectF(38f, y - 20f, 557f, y + 5f), 6f, 6f, palePaint)
            canvas.drawText("DÉTAILS DU RAPPORT", 50f, y - 3f, purplePaint)
            y += 25f

            lines.forEachIndexed { rowIndex, line ->
                val rowTop = y - 14f
                if (rowIndex % 2 == 0) {
                    val rowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.rgb(249, 248, 252)
                    }
                    canvas.drawRect(38f, rowTop, 557f, y + 8f, rowPaint)
                }
                // Les lignes longues sont tronquées proprement dans la largeur imprimable.
                canvas.drawText(line.take(96), 50f, y, bodyPaint)
                y += 19f
            }

            if (pageIndex == groups.lastIndex) {
                val signatureY = maxOf(y + 28f, 730f).coerceAtMost(755f)
                canvas.drawLine(38f, signatureY - 14f, 557f, signatureY - 14f, rulePaint)
                canvas.drawText(
                    "Fait à ${lieuEntreprise.ifBlank { "________________" }}, le " +
                        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
                    38f, signatureY + 7f, smallPaint
                )
                canvas.drawText("Établi par : ${nomGerant.ifBlank { "________________" }}", 38f, signatureY + 28f, boldPaint)
                canvas.drawText("Fonction : ${fonctionGerant.ifBlank { "________________" }}", 38f, signatureY + 46f, bodyPaint)
                canvas.drawLine(380f, signatureY + 45f, 550f, signatureY + 45f, rulePaint)
                canvas.drawText("Signature et cachet", 405f, signatureY + 61f, smallPaint)
            }

            canvas.drawLine(38f, 810f, 557f, 810f, rulePaint)
            canvas.drawText("MelmaTech • Gestion commerciale", 38f, 827f, smallPaint)
            val pagePaint = makePaint(muted, 8f).apply { textAlign = Paint.Align.RIGHT }
            canvas.drawText("Page ${pageIndex + 1}/${groups.size}", 557f, 827f, pagePaint)

            document.finishPage(page)
        }

        val folder = File(context.getExternalFilesDir(null), "Rapports")
        if (!folder.exists()) folder.mkdirs()
        val file = File(folder, "Rapport-${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        return file
    } finally {
        logo?.recycle()
        document.close()
    }
}

@Composable
fun EditeurPhotoProfil(
    bitmap: Bitmap,
    onAnnuler: () -> Unit,
    onValider: (Bitmap) -> Unit
) {
    var zoom by remember { mutableStateOf(1f) }
    var decalage by remember { mutableStateOf(Offset.Zero) }
    var tailleZone by remember { mutableStateOf(IntSize.Zero) }

    Dialog(onDismissRequest = onAnnuler) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(20.dp)
                )
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Recadrer la photo",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(CircleShape)
                    .background(Color.Black)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { tailleZone = it }
                        .pointerInput(bitmap) {
                            detectTransformGestures {
                                    _, pan, zoomChange, _ ->

                                zoom = (zoom * zoomChange)
                                    .coerceIn(1f, 5f)

                                decalage += pan
                            }
                        }
                ) {
                    val cote = minOf(size.width, size.height)

                    val echelleBase = maxOf(
                        cote / bitmap.width,
                        cote / bitmap.height
                    )

                    val echelle = echelleBase * zoom

                    val largeur = bitmap.width * echelle
                    val hauteur = bitmap.height * echelle

                    val gauche =
                        (size.width - largeur) / 2f + decalage.x

                    val haut =
                        (size.height - hauteur) / 2f + decalage.y

                    drawImage(
                        image = bitmap.asImageBitmap(),
                        dstOffset = IntOffset(
                            gauche.roundToInt(),
                            haut.roundToInt()
                        ),
                        dstSize = IntSize(
                            largeur.roundToInt(),
                            hauteur.roundToInt()
                        )
                    )

                    drawCircle(
                        color = Color.White,
                        style = Stroke(width = 3.dp.toPx())
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Déplace et agrandis la photo avec tes doigts.",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = onAnnuler) {
                    Text("Annuler")
                }

                Button(
                    onClick = {
                        val cote = tailleZone.width
                            .coerceAtMost(tailleZone.height)
                            .toFloat()

                        if (cote > 0f) {
                            val echelleBase = maxOf(
                                cote / bitmap.width,
                                cote / bitmap.height
                            )

                            val echelle = echelleBase * zoom

                            val largeur = bitmap.width * echelle
                            val hauteur = bitmap.height * echelle

                            val gauche =
                                (cote - largeur) / 2f + decalage.x

                            val haut =
                                (cote - hauteur) / 2f + decalage.y

                            val centreX =
                                (cote / 2f - gauche) / echelle

                            val centreY =
                                (cote / 2f - haut) / echelle

                            val tailleSource = cote / echelle

                            val x = (centreX - tailleSource / 2f)
                                .roundToInt()
                                .coerceIn(
                                    0,
                                    bitmap.width - tailleSource.roundToInt()
                                )

                            val y = (centreY - tailleSource / 2f)
                                .roundToInt()
                                .coerceIn(
                                    0,
                                    bitmap.height - tailleSource.roundToInt()
                                )

                            val coteSource = tailleSource
                                .roundToInt()
                                .coerceAtLeast(1)
                                .coerceAtMost(
                                    minOf(bitmap.width - x, bitmap.height - y)
                                )

                            val photoRecadree = Bitmap.createBitmap(
                                bitmap,
                                x,
                                y,
                                coteSource,
                                coteSource
                            )

                            onValider(photoRecadree)
                        }
                    }
                ) {
                    Text("Valider")
                }
            }
        }
    }
}
@Composable
fun ActionsProduit(
    onModifier: () -> Unit,
    onCodeBarres: () -> Unit,
    onSupprimer: () -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Modifier
        IconButton(
            onClick = onModifier,
            modifier = Modifier
                .size(40.dp)
                .background(
                    Color(0xFFEEE8FA),
                    RoundedCornerShape(12.dp)
                )
        ) {
            Icon(
                imageVector = Icons.Filled.Edit,
                contentDescription = "Modifier",
                tint = Color(0xFF5426A8),
                modifier = Modifier.size(19.dp)
            )
        }

        // Imprimer le code-barres
        IconButton(
            onClick = onCodeBarres,
            modifier = Modifier
                .size(40.dp)
                .background(
                    Color(0xFFE7F2FF),
                    RoundedCornerShape(12.dp)
                )
        ) {
            Icon(
                imageVector = Icons.Filled.Print,
                contentDescription = "Imprimer le code-barres",
                tint = Color(0xFF2474C6),
                modifier = Modifier.size(19.dp)
            )
        }

        // Supprimer
        IconButton(
            onClick = onSupprimer,
            modifier = Modifier
                .size(40.dp)
                .background(
                    Color(0xFFFCE9E9),
                    RoundedCornerShape(12.dp)
                )
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = "Supprimer",
                tint = Color(0xFFD64545),
                modifier = Modifier.size(19.dp)
            )
        }
    }
}

private fun genererCodesBarresPdf(
    context: Context,
    produits: List<Produit>,
    format: String
): File {
    require(produits.isNotEmpty()) { "Aucun produit à imprimer." }
    val document = PdfDocument()
    val largeur = if (format == "ETIQUETTE") 360 else 595
    val hauteur = if (format == "ETIQUETTE") 180 else 842
    val titre = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.BLACK
        textSize = if (format == "ETIQUETTE") 18f else 10f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    val texte = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.BLACK
        textSize = 10f
    }
    try {
        if (format == "ETIQUETTE") {
            produits.forEachIndexed { index, produit ->
                val page = document.startPage(PdfDocument.PageInfo.Builder(largeur, hauteur, index + 1).create())
                val canvas = page.canvas
                canvas.drawText(produit.nom.take(32), 18f, 28f, titre)
                val code = com.google.zxing.MultiFormatWriter().encode(
                    produit.codeBarres, com.google.zxing.BarcodeFormat.CODE_128, 320, 90
                )
                val bitmap = Bitmap.createBitmap(code.width, code.height, Bitmap.Config.ARGB_8888)
                for (x in 0 until code.width) for (y in 0 until code.height) {
                    bitmap.setPixel(x, y, if (code.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                }
                canvas.drawBitmap(bitmap, null, RectF(18f, 42f, 342f, 132f), null)
                canvas.drawText(produit.codeBarres, 18f, 151f, texte)
                canvas.drawText("Prix : ${String.format(Locale.US, "%.2f", produit.vente)}", 18f, 168f, texte)
                document.finishPage(page)
                bitmap.recycle()
            }
        } else {
            val parPage = 24
            produits.chunked(parPage).forEachIndexed { pageIndex, groupe ->
                val page = document.startPage(PdfDocument.PageInfo.Builder(largeur, hauteur, pageIndex + 1).create())
                val canvas = page.canvas
                val celluleW = largeur / 3f
                val celluleH = hauteur / 8f
                groupe.forEachIndexed { index, produit ->
                    val colonne = index % 3
                    val ligne = index / 3
                    val gauche = colonne * celluleW + 8f
                    val haut = ligne * celluleH + 8f
                    canvas.drawText(produit.nom.take(24), gauche, haut + 12f, titre)
                    val code = com.google.zxing.MultiFormatWriter().encode(
                        produit.codeBarres, com.google.zxing.BarcodeFormat.CODE_128, 170, 55
                    )
                    val bitmap = Bitmap.createBitmap(code.width, code.height, Bitmap.Config.ARGB_8888)
                    for (x in 0 until code.width) for (y in 0 until code.height) {
                        bitmap.setPixel(x, y, if (code.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                    }
                    canvas.drawBitmap(bitmap, null, RectF(gauche, haut + 17f, gauche + celluleW - 16f, haut + 67f), null)
                    canvas.drawText(produit.codeBarres, gauche, haut + 82f, texte)
                    bitmap.recycle()
                }
                document.finishPage(page)
            }
        }
        val dossier = File(context.getExternalFilesDir(null), "CodesBarres")
        if (!dossier.exists()) dossier.mkdirs()
        val fichier = File(dossier, "Codes-barres-${System.currentTimeMillis()}.pdf")
        FileOutputStream(fichier).use { document.writeTo(it) }
        return fichier
    } finally {
        document.close()
    }
}

